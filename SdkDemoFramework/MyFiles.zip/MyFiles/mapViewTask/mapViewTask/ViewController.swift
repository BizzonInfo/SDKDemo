//
//  ViewController.swift
//  mapViewTask
//
//  Created by BonMac21 on 1/27/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit
import MapKit

protocol HandleMapSearch: class {
    func dropPinZoomIn(placemark:MKPlacemark)
}

class ViewController: UIViewController,UIGestureRecognizerDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    let manager = CLLocationManager()
    var array: NSArray!
    var selectedPin: MKPlacemark?
    var resultSearchController: UISearchController!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestWhenInUseAuthorization()
        // manager.startUpdatingLocation()
        let locationSearchTable = self.storyboard!.instantiateViewController(withIdentifier: "LocationTableViewController") as! LocationTableViewController
        resultSearchController = UISearchController(searchResultsController: locationSearchTable)
        resultSearchController.searchResultsUpdater = locationSearchTable
        let searchBar = resultSearchController!.searchBar
        searchBar.sizeToFit()
        searchBar.placeholder = "Search for places"
        navigationItem.titleView = resultSearchController?.searchBar
        resultSearchController.hidesNavigationBarDuringPresentation = false
        resultSearchController.dimsBackgroundDuringPresentation = true
        definesPresentationContext = true
        locationSearchTable.mapView = mapView
        locationSearchTable.handleMapSearchDelegate = self
        let gestureRegonizer = UILongPressGestureRecognizer.init(target: self, action: #selector(handleTap))
        gestureRegonizer.minimumPressDuration = 0.3
        gestureRegonizer.delegate = self
        mapView.addGestureRecognizer(gestureRegonizer)
    }
    
    
    func getDirections(){
        guard let selectedPin = selectedPin else { return }
        let mapItem = MKMapItem(placemark: selectedPin)
        let launchOptions = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
        mapItem.openInMaps(launchOptions: launchOptions)
    }
    
    func handleTap(gestureRegonizer: UIGestureRecognizer) {
        if gestureRegonizer.state == UIGestureRecognizerState.began {
            let location = gestureRegonizer.location(in: mapView)
            let coordinate = mapView.convert(location,toCoordinateFrom: mapView)
            let annotation = MKPointAnnotation()
            annotation.coordinate = coordinate
            let geocoder = CLGeocoder()
            let newLocation = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
            geocoder.reverseGeocodeLocation(newLocation) { (placemarks, error) in
                if error != nil {
                    print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                    return
                }
                if (placemarks?.count)! > 0 {
                    let pm = (placemarks?[0])! as CLPlacemark
                    print(pm.addressDictionary as Any)
                    let locationName = pm.addressDictionary!["FormattedAddressLines"]!
                    self.array = locationName as! NSArray
                    annotation.title = "Dropped pin"
                    annotation.subtitle = "\(self.array[0])" + "," + "\(self.array[1])" + "," + "\(self.array[2])"
                    self.mapView.addAnnotation(annotation)
                }
                else {
                    annotation.title = "Unknown Place"
                    self.mapView.addAnnotation(annotation)
                    print("Problem with the data received from geocoder")
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    
}

//            var placeMark: CLPlacemark!
//            placeMark = placemarks?[0]
//            print(placeMark.addressDictionary!)
//            let locationName = placeMark.addressDictionary!["FormattedAddressLines"]!
//            self.array = locationName as! NSArray
//            annotation.subtitle = "\(self.array[0])" + "," + "\(self.array[1])" + "," + "\(self.array[2])"
//           // annotation.subtitle = "\(locationName!) , \(city) , \(state) , \(zip)" //locationName! + ", " + street! + ", " + city! + ", " + zip!
//        }
//        annotation.title = "Dropped pin"
//        mapView.addAnnotation(annotation)
//    }



//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        let location = locations[0]
//        let span : MKCoordinateSpan = MKCoordinateSpanMake(0.01, 0.01)
//        let mylocation : CLLocationCoordinate2D = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude)
//        let region: MKCoordinateRegion = MKCoordinateRegionMake(mylocation, span)
//        mapView.setRegion(region, animated: true)
//        self.mapView.showsUserLocation = true
//
//    }
extension ViewController : MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if (annotation is MKUserLocation) {
            return nil
        }
        let annotationIdentifier: String = "PinViewAnnotation"
        var pinView: MKPinAnnotationView? = (mapView.dequeueReusableAnnotationView(withIdentifier: annotationIdentifier) as? MKPinAnnotationView)
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: annotationIdentifier)
            pinView?.pinTintColor = .green
            pinView?.animatesDrop = true
            pinView?.canShowCallout = true
            let btn = UIButton(type: .detailDisclosure)
            pinView?.rightCalloutAccessoryView = btn
        }
        else {
            pinView?.annotation = annotation
        }
        return pinView
    }
}

extension ViewController: HandleMapSearch {
    
    func dropPinZoomIn(placemark: MKPlacemark){
        // cache the pin
        selectedPin = placemark
        // clear existing pins
        mapView.removeAnnotations(mapView.annotations)
        let annotation = MKPointAnnotation()
        annotation.coordinate = placemark.coordinate
        annotation.title = placemark.name
        if let city = placemark.locality,
            let state = placemark.administrativeArea {
            annotation.subtitle = "\(city) \(state)"
        }
        mapView.addAnnotation(annotation)
        let span = MKCoordinateSpanMake(0.05, 0.05)
        let region = MKCoordinateRegionMake(placemark.coordinate, span)
        mapView.setRegion(region, animated: true)
    }
}

extension ViewController : CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            manager.requestLocation()
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else { return }
        let span = MKCoordinateSpanMake(0.05, 0.05)
        let region = MKCoordinateRegion(center: location.coordinate, span: span)
        mapView.setRegion(region, animated: true)
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("error:: \(error)")
    }
    
    
}
