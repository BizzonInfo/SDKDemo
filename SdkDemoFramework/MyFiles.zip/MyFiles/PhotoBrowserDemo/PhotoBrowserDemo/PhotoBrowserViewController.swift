//
//  PhotoBrowserViewController.swift
//  PhotoBrowserDemo
//
//  Created by BonMac21 on 5/25/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit
import KSPhotoBrowser
import YYWebImage

class PhotoBrowserViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,KSPhotoBrowserDelegate {
    
    @IBOutlet weak var collectionView: UICollectionView!
    var arrayurls = NSMutableArray()
    var dismissalStyle : KSPhotoBrowserInteractiveDismissalStyle!

    override func viewDidLoad() {
        super.viewDidLoad()
        arrayurls = ["http://ww4.sinaimg.cn/bmiddle/a15bd3a5jw1f12r9ku6wjj20u00mhn22.jpg",
                     "http://ww2.sinaimg.cn/bmiddle/a15bd3a5jw1f01hkxyjhej20u00jzacj.jpg",
                     "http://ww4.sinaimg.cn/bmiddle/a15bd3a5jw1f01hhs2omoj20u00jzwh9.jpg",
                     "http://ww2.sinaimg.cn/bmiddle/a15bd3a5jw1ey1oyiyut7j20u00mi0vb.jpg",
                     "http://ww2.sinaimg.cn/bmiddle/a15bd3a5jw1exkkw984e3j20u00miacm.jpg",
                     "http://ww4.sinaimg.cn/bmiddle/a15bd3a5jw1ezvdc5dt1pj20ku0kujt7.jpg",
                     "http://ww3.sinaimg.cn/bmiddle/a15bd3a5jw1ew68tajal7j20u011iacr.jpg",
                     "http://ww2.sinaimg.cn/bmiddle/a15bd3a5jw1eupveeuzajj20hs0hs75d.jpg"]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    func ks_photoBrowser(_ browser: KSPhotoBrowser, didSelect item: KSPhotoItem, at index: UInt) {
         NSLog("selected index: %d", index)
    }
    

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrayurls.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as? PhotoCollectionViewCell
        cell?.imageViewPhoto?.yy_imageURL = URL(string: arrayurls[indexPath.row] as! String)
        return cell!
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        var items = [KSPhotoItem]()
        for i in 0..<arrayurls.count {
             let cell = collectionView.cellForItem(at: IndexPath(row: i, section: 0)) as? PhotoCollectionViewCell
             let url:String = (arrayurls[i] as AnyObject).replacingOccurrences(of: "bmiddle", with: "large")
             let item = KSPhotoItem(sourceView: (cell?.imageViewPhoto)!, imageUrl: URL(string: url)!)
             items.append(item)
        }
        
        //let cell = collectionView.cellForItem(at: indexPath) as? PhotoCollectionViewCell
       // let item = KSPhotoItem(sourceView: (cell?.imageViewPhoto)!, imageUrl: URL(string: self.arrayurls[indexPath.row] as! String)!)
      //  let item = KSPhotoItem(sourceView: (cell?.imageViewPhoto)!, imageUrl: URL(string: self.arrayurls as! String)!)
     //   items.append(item)
        let browser = KSPhotoBrowser(photoItems: items, selectedIndex: 0)
        browser.delegate = self
        browser.dismissalStyle = .slide
        browser.pageindicatorStyle = .dot
        browser.backgroundStyle = .blurPhoto
        browser.loadingStyle = .determinate
        browser.show(from: self)
    }


}
