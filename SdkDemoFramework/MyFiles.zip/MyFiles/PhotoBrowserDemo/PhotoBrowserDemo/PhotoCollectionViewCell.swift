//
//  PhotoCollectionViewCell.swift
//  PhotoBrowserDemo
//
//  Created by BonMac21 on 5/25/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    
@IBOutlet weak var imageViewPhoto: UIImageView!
    
}
