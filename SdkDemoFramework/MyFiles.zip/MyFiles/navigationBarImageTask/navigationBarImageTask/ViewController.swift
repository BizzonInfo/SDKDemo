//
//  ViewController.swift
//  navigationBarImageTask
//
//  Created by BonMac21 on 3/1/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
  
    

    override func viewDidLoad() {
        super.viewDidLoad()
        let navView = UIView()
        navView.backgroundColor = UIColor.red
        
        // Create the label
        let label = UILabel()
        label.text = "Abiram"
        label.sizeToFit()
        label.center = navView.center
        label.textAlignment = NSTextAlignment.center
        
        
        let image = UIImageView()
        image.image = UIImage(named: "Name")
        
        let imageAspect = image.image!.size.width/image.image!.size.height
        
       // image.frame = CGRect(x: label.frame.origin.x-label.frame.size.height*imageAspect, y: label.frame.origin.y, width: label.frame.size.height*imageAspect, height: label.frame.size.height)
        
        
        
       
        image.frame = CGRect(x: 0, y: -18, width: 20, height: 20)
         label.frame = CGRect(x: -4, y: 4, width: 70, height: 15)
        image.contentMode = UIViewContentMode.scaleAspectFit
        label.font = UIFont(name: label.font.fontName, size: 12)
       
        navView.addSubview(label)
        navView.addSubview(image)
        
       
        self.navigationItem.titleView = navView
        
       
        navView.sizeToFit()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

