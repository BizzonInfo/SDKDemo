//
//  ViewController.swift
//  SimpleUserDefaults
//
//  Created by BonMac21 on 1/23/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var textFieldFirstName: UITextField!
    @IBOutlet weak var textFieldLastName: UITextField!
    @IBOutlet weak var clearButton: UIButton!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
       
        
    }
    
    @IBAction func buttonSavePressed(_ sender: UIButton) {
        UserDefaults.standard.set(textFieldFirstName.text, forKey: "FirstName")
        UserDefaults.standard.set(textFieldLastName.text, forKey: "LastName")
        UserDefaults.standard.synchronize()
    }
 
    @IBAction func buttonClearPressed(_ sender: Any) {
        if textFieldFirstName.text == "" {
           loadDefaults()
           clearButton.setTitle("CLEAR", for: .normal)
        } else {
            textFieldFirstName.text = ""
            textFieldLastName.text = ""
            clearButton.setTitle("LOAD", for: .normal)
        }
    }
    
    func loadDefaults () {
      let defaults = UserDefaults.standard
        textFieldFirstName.text = defaults.object(forKey: "FirstName") as! String?
        textFieldLastName.text = defaults.object(forKey: "LastName") as! String?
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

