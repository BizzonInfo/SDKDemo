//
//  ListTableViewCell.swift
//  ListAndGridViewApplication
//
//  Created by BonMac21 on 1/9/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit
import SWTableViewCell

class ListTableViewCell: SWTableViewCell {
    
    @IBOutlet weak var imageViewdisplayImage: UIImageView!
    @IBOutlet weak var labelName: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
