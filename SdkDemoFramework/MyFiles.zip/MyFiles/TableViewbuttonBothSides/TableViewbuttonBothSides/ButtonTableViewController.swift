//
//  ButtonTableViewController.swift
//  TableViewbuttonBothSides
//
//  Created by BonMac21 on 1/13/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit
import SWTableViewCell


class ButtonTableViewController: UITableViewController ,SWTableViewCellDelegate {
    
    
    
    var fruitsNameArray = ["Apple","Orange","Pome","Banana","Guava","Papaya","Watermelon","Pineapple","Strawberry"]
    var imageArray = [UIImage.init(named: "Apple"),UIImage.init(named: "Orange"), UIImage.init(named: "Pome"),UIImage.init(named: "Banana"), UIImage.init(named: "Guava"), UIImage.init(named: "Papaya"), UIImage.init(named: "Watermelon"), UIImage.init(named: "Pineapple"),UIImage.init(named: "Strawberry")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fruitsNameArray.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell") as! ListTableViewCell
        let leftUtilityButtons: NSMutableArray = NSMutableArray()
        let rightUtilityButtons: NSMutableArray = NSMutableArray()
        leftUtilityButtons.sw_addUtilityButtonWithColor(UIColor.clearColor(), icon: UIImage.init(named: "LeftButton1"))
        leftUtilityButtons.sw_addUtilityButtonWithColor(UIColor.clearColor(), icon: UIImage.init(named: "LeftButton2"))
        let myattribute = [NSForegroundColorAttributeName: UIColor.redColor()]
        let myAttributedString1 = NSAttributedString(string: "Right1", attributes: myattribute)
        rightUtilityButtons.sw_addUtilityButtonWithColor(UIColor.clearColor(), attributedTitle: myAttributedString1)
       // rightUtilityButtons.sw_addUtilityButtonWithColor(UIColor.clearColor(), icon: UIImage.init(named: "RightButton1"))
        let myAttributedString2 = NSAttributedString(string: "Right2", attributes: myattribute)
        rightUtilityButtons.sw_addUtilityButtonWithColor(UIColor.clearColor(), attributedTitle: myAttributedString2)
        let mystring = "Right3"
        let myAttributedString3 = NSAttributedString(string: mystring, attributes: myattribute)
        rightUtilityButtons.sw_addUtilityButtonWithColor(UIColor.clearColor(), attributedTitle: myAttributedString3)
        cell.leftUtilityButtons = leftUtilityButtons as [AnyObject]
        cell.rightUtilityButtons = rightUtilityButtons as [AnyObject]
        cell.delegate = self
        cell.labelName.text = fruitsNameArray[indexPath.row]
        cell.imageViewdisplayImage.image = imageArray[indexPath.row]
        return cell
    }
    
    func swipeableTableViewCell(cell: SWTableViewCell!, didTriggerLeftUtilityButtonWithIndex index: Int) {
        switch index {
        case 0:
           print("Left Button One")
           break
        case 1:
            print("Left Button Two")
            break
        default:
            break
        }
    }
    
    func swipeableTableViewCell(cell: SWTableViewCell!, didTriggerRightUtilityButtonWithIndex index: Int) {
        switch index {
        case 0:
            print("Right Button One")
            break
        case 1:
            print("Right Button Two")
            break
        case 2:
            print("Right Button Three")
        default:
            break
        }
        
    }
    
    func swipeableTableViewCellShouldHideUtilityButtonsOnSwipe(cell: SWTableViewCell!) -> Bool {
        return true
    }
    
    
    

}
