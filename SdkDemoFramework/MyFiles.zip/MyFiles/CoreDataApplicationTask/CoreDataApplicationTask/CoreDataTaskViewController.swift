//
//  CoreDataTaskViewController.swift
//  CoreDataApplicationTask
//
//  Created by BonMac21 on 12/26/16.
//  Copyright © 2016 BonMac21. All rights reserved.
//

import UIKit
import CoreData

class CoreDataTaskViewController: UIViewController {
    
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    @IBOutlet weak var textFieldName: UITextField!
    @IBOutlet weak var textFieldAddress: UITextField!
    @IBOutlet weak var textFieldphone: UITextField!
    @IBOutlet weak var labelStatus: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveContact(_ sender: Any) {
       let entityDescription = NSEntityDescription.entity(forEntityName: "Contacts", in: managedObjectContext)
       let contact = Contacts(entity: entityDescription!, insertInto: managedObjectContext)
        contact.name = textFieldName.text
        contact.address = textFieldAddress.text
        contact.phone = textFieldphone.text
        do {
            try managedObjectContext.save()
            textFieldName.text = ""
            textFieldphone.text = ""
            textFieldAddress.text = ""
            labelStatus.text = "Contact Saved"
        } catch let error {
            labelStatus.text = error.localizedDescription
            
        }
    }
    
    
    @IBAction func retrieveContact(_ sender: Any) {
        let entityDescription = NSEntityDescription.entity(forEntityName: "Contacts", in: managedObjectContext)
        let request: NSFetchRequest<Contacts> = Contacts.fetchRequest()
        request.entity = entityDescription
        let pred = NSPredicate(format : "(name = %@)", textFieldName.text!)
        request.predicate = pred
        do {
            var results = try managedObjectContext.fetch(request as! NSFetchRequest<NSFetchRequestResult>)
            if results.count > 0{
                let match = results[0] as! NSManagedObject
                textFieldName.text = match.value(forKey: "name") as? String
                textFieldAddress.text = match.value(forKey: "address") as? String
                textFieldphone.text = match.value(forKey: "phone") as? String!
                labelStatus.text = "Matches found: \(results.count)"
            } else {
                labelStatus.text  = "No Match"
            }
        } catch let error {
            labelStatus.text = error.localizedDescription
        }
    }
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    



}
