//
//  HomeTableViewController.swift
//  ExpandableSideMenuTask
//
//  Created by BonMac21 on 3/24/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class HomeTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       self.setNavigationBarItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
      
    }

    // MARK: - Table view data source

    

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return 6
    }


    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "Cell") as! HomeTableViewCell
        cell.textLabel?.text = "Row \(indexPath.row)"
        return cell
    }
    
    

}
