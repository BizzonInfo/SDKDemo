//
//  ExpandableCellTableViewController.swift
//  ExpandableSideMenuTask
//
//  Created by BonMac21 on 3/24/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

enum HomeMenu: Int {
    case dashboard = 0
    //    case employees
}

enum EmployeeMenu:Int{
    case employees
}

enum KPIMenu: Int {
    
    case categories
    case kPIs
    case categoryKPIAssign
    case boards
    case concerns
    case reports
    case rootCauseAnalysis
}

enum CBOMMenu:Int{
    case cBOM_Plans
    case cBOM_UploadKPIs
    case cBOM_Board
    case cBOM_Concerns
    case cBOM_Reports
    case cBOM_rootCauseAnalysis
}

enum TicketsMenu:Int{
    case myTickets
    case manageTickets
}

enum SettingsMenu:Int{
    case departments
    case designations
    case kPIUnits
    case failureCodes
}



class ExpandableCellTableViewController: UITableViewController {
    
     var expandedSection:NSMutableSet = []
    
    var arraySectionTitle = ["Dashboard","Employees","KPI","CBOM","Tickets","Settings","Logout"]
    var arrayRowKPIContents = ["Categories","KPIs","Category KPI Assign","Board","Concerns","Reports","Root Cause Analysis"]
    var arrayRowCBOMContents = ["Plans","Upload KPIs","Board","Concerns","Reports","Root Cause Analysis"]
    var arrayRowTicketsContents = ["My Tickets","Manage Tickets"]
    var arrayRowSettingsContents = ["Departments","Designations","KPI Units","Failure Codes"]
    

    override func viewDidLoad() {
        super.viewDidLoad()

     
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
     
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return self.arraySectionTitle.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if expandedSection.contains(section) {
            switch section {
            case 0:
                return 0
            case 1:
                return 0
            case 2:
                return self.arrayRowKPIContents.count
            case 3:
                return self.arrayRowCBOMContents.count
            case 4:
                return self.arrayRowTicketsContents.count
            case 5:
                return self.arrayRowSettingsContents.count
            case 6:
                return 0
            default:
                return 0
            }
        } else {
            return 0
        }
        
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! ExpandableTableViewCell
        let sectionIndex = indexPath.section
        if sectionIndex == 0 {
            cell.labelDisplayText.text = "Dashboard"
        } else if sectionIndex == 1 {
            cell.labelDisplayText.text = "Employees"
        } else if sectionIndex == 2 {
            cell.labelDisplayText.text = arrayRowKPIContents[indexPath.row]
        } else if sectionIndex == 3 {
            cell.labelDisplayText.text = arrayRowCBOMContents[indexPath.row]
        } else if sectionIndex == 4 {
            cell.labelDisplayText.text = arrayRowTicketsContents[indexPath.row]
        } else if sectionIndex == 5 {
            cell.labelDisplayText.text = arrayRowSettingsContents[indexPath.row]
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44
    }

}
