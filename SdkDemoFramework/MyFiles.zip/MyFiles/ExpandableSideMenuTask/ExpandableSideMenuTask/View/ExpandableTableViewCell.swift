//
//  ExpandableTableViewCell.swift
//  ExpandableSideMenuTask
//
//  Created by BonMac21 on 3/24/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class ExpandableTableViewCell: UITableViewCell {
    
    @IBOutlet weak var labelDisplayText: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
