//
//  C2DEditOrderTableViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/21/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DEditOrderTableViewController: UITableViewController {

    @IBOutlet var tableViewHeader: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 5
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "editOrderList", for: indexPath) as! C2DEditOrderTableViewCell

        

        return cell
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return tableViewHeader
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 82
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.backgroundColor = .clear
    }
    
    @IBAction func increaseCountPressed(_ sender: UIButton) {
//        recipeCount = recipeCount+1
//        self.labelPopUpRecipeCount.text = "\(recipeCount)"
    }
    
    @IBAction func decreaseCountPressed(_ sender: UIButton) {
//        if recipeCount == 1{
//            CAUtils.showToastWithTitle("Minimum quantity is 1")
//        }else{
//            recipeCount = recipeCount-1
//            self.labelPopUpRecipeCount.text = "\(recipeCount)"
//        }
    }
}
