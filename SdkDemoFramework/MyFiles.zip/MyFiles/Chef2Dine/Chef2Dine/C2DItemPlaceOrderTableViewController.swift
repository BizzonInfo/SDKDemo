//
//  C2DItemPlaceOrderTableViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/19/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DItemPlaceOrderTableViewController: UITableViewController {

    @IBOutlet var imageViewItem: UIImageView!
    @IBOutlet var labelRecipeName: UILabel!
    @IBOutlet var labelRecipePrice: UILabel!
    
    @IBOutlet var labelProcessingTime: UILabel!
    @IBOutlet var textViewDescription: UITextView!
    
    @IBOutlet var addOrderPopUpView: UIView!
    
    @IBOutlet var labelPopUpRecipeName: UILabel!
    @IBOutlet var labelPopUpRecipeCount: UILabel!
    @IBOutlet var textViewPopUpRemarks: UITextView!
    
    var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.dark)
    var blurEffectView = UIVisualEffectView()
    
    var recipeCount = 1
    
    var isOrderPlaced = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.addOrderPopUpView.backgroundColor = .clear
        self.addOrderPopUpView.layer.borderColor = UIColor.red.cgColor
        self.addOrderPopUpView.layer.borderWidth = 1.0
        
        self.textViewPopUpRemarks.layer.borderColor = UIColor.white.cgColor
        self.textViewPopUpRemarks.layer.borderWidth = 1.0
        self.textViewPopUpRemarks.tintColor = .white
        self.textViewPopUpRemarks.text = ""
        
        self.labelPopUpRecipeCount.text = "\(recipeCount)"
        
        self.textViewDescription.layer.borderColor = UIColor.red.cgColor
        self.textViewDescription.layer.borderWidth = 1.0
        
        self.textViewPopUpRemarks.inputAccessoryView = CAUtils.getDoneToolBarButton(tableView: self, target: #selector(self.dismissKeyboard))
        
        let homeButton = UIBarButtonItem(image: UIImage(named: "Home"), style: .plain, target: self, action: #selector(self.homeButtonPressed))
        self.navigationItem.rightBarButtonItem = homeButton
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: TableView Delegate
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.backgroundColor = .clear
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if !isOrderPlaced{
            if indexPath.row == 0{
                return 239
            }else if indexPath.row == 1{
                return 145
            }
            else if indexPath.row == 2{
                return 44
            }else if indexPath.row == 3{
                return 0
            }else{
                return 0
            }
        }else{
            if indexPath.row == 0{
                return 239
            }else if indexPath.row == 1{
                return 145
            }
            else if indexPath.row == 2{
                return 0
            }else if indexPath.row == 3{
                return 44
            }else{
                return 0
            }
        }
    }

    // MARK: - Button Actions
    
    func dismissKeyboard(){
        self.view.endEditing(true)
    }
    
    func homeButtonPressed(){
        _ = self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func increaseCountPressed(_ sender: UIButton) {
        recipeCount = recipeCount+1
        self.labelPopUpRecipeCount.text = "\(recipeCount)"
    }
    
    @IBAction func decreaseCountPressed(_ sender: UIButton) {
        if recipeCount == 1{
            CAUtils.showToastWithTitle("Minimum quantity is 1")
        }else{
            recipeCount = recipeCount-1
            self.labelPopUpRecipeCount.text = "\(recipeCount)"
        }
    }
    
    @IBAction func placeOrderPressed(_ sender: UIButton) {
        isOrderPlaced = true
        removeBlur()
        animateOut()
        self.tableView.reloadData()
    }
    
    @IBAction func addToOrderPressed(_ sender: UIButton) {
        viewPlaceOrderOptions()
        blur()
        animateIn()
    }
    @IBAction func removeFromOrderPressed(_ sender: UIButton) {
        isOrderPlaced = false
        self.tableView.reloadData()
    }
    
    @IBAction func updateOrderPressed(_ sender: UIButton) {
        viewPlaceOrderOptions()
        blur()
        animateIn()
    }
    
    //MARK:- iPopUP Functions
    
    override func viewDidAppear(_ animated: Bool) {
        addOrderPopUpView.setNeedsFocusUpdate()
    }
    override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        addOrderPopUpView.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: view.frame.width - 50, height: 285))
        addOrderPopUpView.center = view.center
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches , with:event)
        if touches.first != nil{
            removeBlur()
            animateOut()
        }
    }
    
    func touchesView(){//tapAction
        removeBlur()
        animateOut()
    }
    @IBAction func dismissPopUp(_ sender: AnyObject) {
        removeBlur()
        animateOut()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        removeBlur()
        animateOut()
    }
    
    public func removeBlur() {
        blurEffectView.removeFromSuperview()
    }
    
    func viewPlaceOrderOptions(){
        if !CAUtils.isiPhone(){
            addOrderPopUpView.frame.origin.x = 0
            addOrderPopUpView.frame.origin.y = 0
        }
        else{
            if GlobalVariables.sharedManager.rotated() == true{
                addOrderPopUpView.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: view.frame.width - 50, height: 285))
            }
            else {
                addOrderPopUpView.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: view.frame.width - 50, height: 285))
            }
        }
        addOrderPopUpView.layer.cornerRadius = 5 //make oval view edges
    }
    
    func blur(){
        blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight] // for supporting device rotation
        view.addSubview(blurEffectView)
        
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(self.touchesView))
        singleTap.numberOfTapsRequired = 1
        self.blurEffectView.addGestureRecognizer(singleTap)
    }
    
    func animateIn() {
        self.view.addSubview(addOrderPopUpView)
        addOrderPopUpView.center = self.view.center
        addOrderPopUpView.transform = CGAffineTransform.init(scaleX: 1.3, y: 1.3)
        addOrderPopUpView.alpha = 0
        UIView.animate(withDuration: 0.4) {
            self.addOrderPopUpView.alpha = 1
            self.addOrderPopUpView.transform = CGAffineTransform.identity
        }
    }
    
    public func animateOut () {
        UIView.animate(withDuration: 0.3, animations: {
            self.addOrderPopUpView.transform = CGAffineTransform.init(scaleX: 2.0, y: 2.0)
            self.addOrderPopUpView.alpha = 0
        }) { (success:Bool) in
            self.addOrderPopUpView.transform = CGAffineTransform.init(scaleX: 1.0, y: 1.0)
            self.addOrderPopUpView.removeFromSuperview()
        }
    }
}
