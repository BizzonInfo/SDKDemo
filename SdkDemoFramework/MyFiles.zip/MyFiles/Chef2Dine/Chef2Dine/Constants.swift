//
//  Constants.swift
//  CompassForSuccess
//
//  Created by Bon User on 9/5/16.
//  Copyright © 2016 Bon User. All rights reserved.
//

import Foundation

let device_token="DEVICE_TOKEN"

let orderAcceptColorCode = "0ca500"

let orderRejectColorCode = "FF0000"

let materialRedColor = "FF4F49"

let USERNAME="USERNAME"

let USERFULLNAME="USERFULLNAME"

let ACCESS_TOKEN = "access_token"

let CAFENAME = "CafeName"

let PASSWORD="PASSWORD"

let USER_ID = "USER_ID"

let EMAIL = "EMAIL"

var STATUS_CODE = 200

var currencySymbol = "CURRENCY"

let barTintColor = "FF4F49"

let deviceId = "DEVICE_ID"

let deviceHandShake = "Device_HandShake"

let deviceCode = "Device_Code"

let USERABLE_TYPE = "UserableType"

//live server

 // CHEF2DINE SERVER API URLS

let adminBaseURL = "http://cafe.chef2dine.com/api/"

let superAdminBaseURL = "http://admin.chef2dine.com/api/"

//MAD-FRIES API URLS

//let adminBaseURL = "http://cafe.madfries.chef2dine.com/api/"
//
//let superAdminBaseURL = "http://admin.madfries.chef2dine.com/api/"

