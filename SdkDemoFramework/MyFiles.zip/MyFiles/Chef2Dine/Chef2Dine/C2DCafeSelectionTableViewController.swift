//
//  C2DCafeSelectionTableViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/23/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit
import Alamofire

class C2DCafeSelectionTableViewController: UITableViewController {

    let access_token = "\(UserDefaults.standard.value(forKey: ACCESS_TOKEN)!)"
    var arrayCafeDetails = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getCafeDetails()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    func getCafeDetails(){
        
        CAUtils.showLoadingViewWithTitle("Loading Cafes")
        let dicHeaderDetails = NSDictionary(objects: ["Bearer \(access_token)"], forKeys: ["Authorization" as NSCopying])
        _ = Alamofire.request(superAdminBaseURL+"api-authenticate", method: .get, parameters: nil , encoding: JSONEncoding.default, headers: dicHeaderDetails as? HTTPHeaders).responseJSON(completionHandler: { (response) in
            
            if let result = response.result.value{
                let dicResult = result as! NSDictionary
                let arrayCafeData = dicResult["cafe_details"] as! NSArray
                self.arrayCafeDetails.removeAllObjects()
                for item in arrayCafeData{
                    let dicCafeDetails = item as! NSDictionary
                    self.arrayCafeDetails.add(dicCafeDetails)
                }
                CAUtils.removeLoadingView(nil)
                self.tableView.reloadData()
            }
            else{
                CAUtils.removeLoadingView(nil)
                CAUtils.showAlertViewControllerWithTitle("Some error occured, Try again later", message: response.result.error?.localizedDescription, cancelButtonTitle: "OK")
            }
            
        })
    }
    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.arrayCafeDetails.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CafeList", for: indexPath)
        let dicData = self.arrayCafeDetails[indexPath.row] as! NSDictionary
        cell.textLabel?.textColor = .white
        cell.textLabel?.text = "\(dicData["name"]!)"
        cell.layer.shadowColor = UIColor.red.cgColor
        cell.layer.shadowOffset = CGSize(width: 2, height: 2)
        let shadowFrame = CGRect(x: 0, y: cell.frame.height-1, width: cell.frame.width, height: 3)
        let shadowPath = UIBezierPath(rect: shadowFrame).cgPath
        cell.layer.shadowPath = shadowPath
        cell.layer.shadowOpacity = 1.0
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dicData = self.arrayCafeDetails[indexPath.row] as! NSDictionary
        UserDefaults.standard.setValue("\(dicData["name"]!)", forKey: CAFENAME)
        let deviceSelection = self.storyboard?.instantiateViewController(withIdentifier: "DeviceSelection") as! C2DDeviceSelectionTableViewController
        deviceSelection.dicCafeDetails = dicData
        UIView.beginAnimations("Flip", context: nil)
        UIView.setAnimationDuration(1.0)
        UIView.setAnimationCurve(UIViewAnimationCurve.easeInOut)
        UIView.setAnimationTransition(UIViewAnimationTransition.flipFromRight, for: (self.navigationController?.view)!, cache: false)
        self.navigationController?.pushViewController(deviceSelection, animated: true)
        UIView.commitAnimations()
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.backgroundColor = .clear
    }
}
