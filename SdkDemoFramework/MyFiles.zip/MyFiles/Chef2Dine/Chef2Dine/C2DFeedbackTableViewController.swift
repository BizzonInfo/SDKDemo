//
//  C2DFeedbackTableViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/19/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DFeedbackTableViewController: UITableViewController,FloatRatingViewDelegate,UITextFieldDelegate,UITextViewDelegate {

    @IBOutlet var floatRatingViewFeedback: FloatRatingView!
    
    @IBOutlet var textViewSuggestions: UITextView!
    
    @IBOutlet var textEmail: JJMaterialTextfield!
    @IBOutlet var textBillNumber: JJMaterialTextfield!
    
    @IBOutlet var buttonSubmitFeedback: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        floatRatingViewFeedback.delegate = self
        floatRatingViewFeedback.rating = 5.0
        
        self.textViewSuggestions.text = "Excellent"
        
        self.textViewSuggestions.layer.borderColor = UIColor.red.cgColor
        self.textViewSuggestions.layer.borderWidth = 1.0
        self.textViewSuggestions.inputAccessoryView = CAUtils.getDoneToolBarButton(tableView: self, target: #selector(self.dismissKeyboard))
        
        let homeButton = UIBarButtonItem(image: UIImage(named: "Home"), style: .plain, target: self, action: #selector(self.homeButtonPressed))
        self.navigationItem.rightBarButtonItem = homeButton
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.title = "Feedback"
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.backgroundColor = .clear
    }
    
    // MARK: - Button Actions
    
    func homeButtonPressed(){
        _ = self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func submitFeedbackPressed(_ sender: UIButton) {
    }
    
    func dismissKeyboard(){
        self.view.endEditing(true)
    }
    
    //MARK:- TextField Delegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let nextTag = textField.tag+1
        let nextResponder = textField.superview?.superview?.superview?.viewWithTag(nextTag)
        if nextResponder != nil{
            nextResponder?.becomeFirstResponder()
        }else{
            textField.resignFirstResponder()
        }
        return false
    }
    //MARK:- TextView Delegate
    func textViewDidBeginEditing(_ textView: UITextView) {
        if self.textViewSuggestions.text == "Suggestions"{
            self.textViewSuggestions.text=""
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if self.textViewSuggestions.text == ""{
            self.textViewSuggestions.text="Suggestions"
        }
    }
    //MARK:- Float Rating View Delegates
    
    func floatRatingView(_ ratingView: FloatRatingView, didUpdate rating: Float) {
        if rating == 1.0{
            self.textViewSuggestions.text = "Low"
        }else if rating == 2.0 {
            self.textViewSuggestions.text = "Average"
        }else if rating == 3.0 {
            self.textViewSuggestions.text = "Good"
        }else if rating == 4.0 {
            self.textViewSuggestions.text = "Best"
        }else if rating == 5.0 {
            self.textViewSuggestions.text = "Excellent"
        }
    }
    
    func floatRatingView(_ ratingView: FloatRatingView, isUpdating rating: Float) {
        if rating == 1.0{
            self.textViewSuggestions.text = "Low"
        }else if rating == 2.0 {
            self.textViewSuggestions.text = "Average"
        }else if rating == 3.0 {
            self.textViewSuggestions.text = "Good"
        }else if rating == 4.0 {
            self.textViewSuggestions.text = "Best"
        }else if rating == 5.0 {
            self.textViewSuggestions.text = "Excellent"
        }
    }
}
