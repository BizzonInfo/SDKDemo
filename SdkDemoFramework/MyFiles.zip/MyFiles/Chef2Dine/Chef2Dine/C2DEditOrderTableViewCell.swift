//
//  C2DEditOrderTableViewCell.swift
//  Chef2Dine
//
//  Created by Bon User on 1/21/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DEditOrderTableViewCell: UITableViewCell {

    @IBOutlet var imageViewRecipe: UIImageView!
    @IBOutlet var labelRecipeName: UILabel!
    @IBOutlet var labelRecipeAmount: UILabel!
    @IBOutlet var labelRecipeCount: UILabel!
    @IBOutlet var labelRecipeTime: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
