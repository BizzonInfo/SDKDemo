//
//  C2DItemsDetailsListTableViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/19/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DItemsDetailsListTableViewController: UITableViewController {

    var arrayItems = ["Omlets","From the Griddle","Beverages"]//NSMutableArray()
    
    var moreButton = UIBarButtonItem()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        moreButton = UIBarButtonItem(image: UIImage(named:"MoreIcon"), style: .plain, target: self, action: #selector(self.moreButtonAction))
        self.navigationItem.rightBarButtonItem = moreButton
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.title = "Items"
    }

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.arrayItems.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "itemDetails", for: indexPath) as! C2DItemDetailsTableViewCell

        cell.customizeCellWithDetails(itemName: self.arrayItems[indexPath.row], itemImageName: "")

        cell.layer.shadowColor = UIColor.red.cgColor
        cell.layer.shadowOffset = CGSize(width: 1, height: 0)
        let shadowFrame = CGRect(x: 0, y: cell.frame.height-1, width: cell.frame.width, height: 2)
        let shadowPath = UIBezierPath(rect: shadowFrame).cgPath
        cell.layer.shadowPath = shadowPath
        cell.layer.shadowOpacity = 0.5

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let itemVariants = self.storyboard?.instantiateViewController(withIdentifier: "itemVariantsPage") as! C2DItemVariantsTableViewController
        self.navigationController?.pushViewController(itemVariants, animated: true)
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if !CAUtils.isiPhone(){
            return 300
        }else{
            return 197
        }
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.backgroundColor = .clear
    }
    
    //MARK:- Button Actions
    
    func moreButtonAction(){
        let moreActionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        let logout = UIAlertAction(title: "Logout", style: .default) { (action) in
            self.logoutAction()
        }
        let feedback = UIAlertAction(title: "Feedback", style: .default) { (action) in
            let feedbackPage = self.storyboard?.instantiateViewController(withIdentifier: "FeedbackPage") as! C2DFeedbackTableViewController
            self.navigationController?.pushViewController(feedbackPage, animated: true)
        }
        let home = UIAlertAction(title: "Home", style: .default) { (action) in
            _=self.navigationController?.popToRootViewController(animated: true)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
            self.dismiss(animated: true, completion: nil)
        }
        moreActionSheet.addAction(home)
        moreActionSheet.addAction(feedback)
        moreActionSheet.addAction(logout)
        moreActionSheet.addAction(cancelAction)
        
        self.present(moreActionSheet, animated: true, completion: nil)
        if !CAUtils.isiPhone(){
            let popOver = moreActionSheet.popoverPresentationController
            popOver?.barButtonItem = moreButton
        }
    }
    
    func logoutAction(){
        let logoutAlert = UIAlertController(title: "Do you want to logout?", message: nil, preferredStyle: .actionSheet)
        logoutAlert.addAction(UIAlertAction(title: "Logout", style: .destructive, handler: { (action) in
            let delegate = UIApplication.shared.delegate as! AppDelegate
            delegate.logout()
        }))
        logoutAlert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { (action) in
            self.dismiss(animated: true, completion: nil)
        }))
        self.present(logoutAlert, animated: true, completion: nil)
        
        if !CAUtils.isiPhone(){
            let popOver = logoutAlert.popoverPresentationController
            popOver?.barButtonItem = self.moreButton
        }
    }
}
