//
//  C2DCafeLoginViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/23/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit
import Alamofire

class C2DCafeLoginViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet var viewLoginCredentials: UIView!
    @IBOutlet var labelName: UILabel!
    @IBOutlet var textUserName: JJMaterialTextfield!
    @IBOutlet var textPassword: JJMaterialTextfield!

    override func viewDidLoad() {
        super.viewDidLoad()
        if !CAUtils.isiPhone(){
            viewLoginCredentials.frame = CGRect(x: 0, y: 0, width: self.view.frame.width-50, height: 200)
        }else{
            viewLoginCredentials.frame = CGRect(x: 0, y: 0, width: self.view.frame.width-50, height: 181)
        }
        
        viewLoginCredentials.center = self.view.center
        
        self.viewLoginCredentials.layer.borderColor = UIColor.red.cgColor
        self.viewLoginCredentials.layer.borderWidth = 1.0
        
        self.labelName.text = "Cafe Login"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func loginPressed(_ sender: UIButton) {
        self.loginAPICall()
    }

    func loginAPICall(){
        if CAUtils.isWhiteSpace(self.textUserName.text!) || CAUtils.isWhiteSpace(textPassword.text!) {
            CAUtils.showToastWithTitle("Credentials missing")
            return
        }
        
        if CAUtils.isWhiteSpace(textUserName.text!) || CAUtils.isWhiteSpace(textPassword.text!){
            CAUtils.showToastWithTitle("Enter your credentials")
            return
        }
        else{
            CAUtils.showLoadingViewWithTitle("Loading...")
            let arrayValues = ["CAFE-ADMIN","password","password",self.textUserName.text!,self.textPassword.text!]
            let arraykeys = ["client_id","client_secret","grant_type","username","password"]
            let dicData = NSDictionary(objects: arrayValues, forKeys: arraykeys as [NSCopying])
            _ = Alamofire.request(superAdminBaseURL+"token", method: .post, parameters: dicData as? Parameters, encoding: JSONEncoding.default, headers: [:]).responseJSON(completionHandler: { (response) in
                if let result = response.result.value{
                    let dictJSON = result as! NSDictionary
                    self.getSuperAdminDetails(access_token: "\(dictJSON["access_token"]!)")
                    CAUtils.removeLoadingView(nil)
                }
                else{
                    CAUtils.removeLoadingView(nil)
                    CAUtils.showAlertViewControllerWithTitle("Some error occured, Try again later", message: response.result.error?.localizedDescription, cancelButtonTitle: "OK")
                }
            })
        }
    }
    
    func getSuperAdminDetails(access_token:String){
        CAUtils.showLoadingViewWithTitle("Loading Admin Details")
        let dicHeaderDetails = NSDictionary(objects: ["Bearer \(access_token)"], forKeys: ["Authorization" as NSCopying])
        _ = Alamofire.request(superAdminBaseURL+"token", method: .get, parameters: nil , encoding: JSONEncoding.default, headers: dicHeaderDetails as? HTTPHeaders).responseJSON(completionHandler: { (response) in
            
            if let result = response.result.value{
                CAUtils.removeLoadingView(nil)
                let dictJSON = result as! NSDictionary
                print(dictJSON)
                
                UserDefaults.standard.setValue(access_token, forKey: ACCESS_TOKEN)
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let mainView = storyboard.instantiateViewController(withIdentifier: "CafeList") as! C2DInitialCafeLoginTableViewController
                let delegate = UIApplication.shared.delegate as! AppDelegate
                delegate.window?.rootViewController = mainView
                delegate.window?.makeKeyAndVisible()

            }
            else{
                CAUtils.removeLoadingView(nil)
                CAUtils.showAlertViewControllerWithTitle("Some error occured, Try again later", message: response.result.error?.localizedDescription, cancelButtonTitle: "OK")
            }
        })
    }
    
    //MARK:- Textfield Delegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let nextTag = textField.tag+1
        let nextResponder = textField.superview?.superview?.superview?.viewWithTag(nextTag)
        if nextResponder != nil{
            nextResponder?.becomeFirstResponder()
        }else{
            textField.resignFirstResponder()
        }
        return false
    }

}
