//
//  C2DInitialCafeLoginTableViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/23/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit
import Alamofire

class C2DInitialCafeLoginTableViewController: UITableViewController,UITextFieldDelegate {

    @IBOutlet var containerViewCafe: UIView!
    
    var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.dark)
    var blurEffectView = UIVisualEffectView()

    override func viewDidLoad() {
        super.viewDidLoad()
        CAUtils.setBackgroundForTableView(tableView: self.tableView)
        
        self.containerViewCafe.layer.cornerRadius = 10.0
        self.containerViewCafe.backgroundColor = UIColor.black.withAlphaComponent(0.5)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.backgroundColor = .clear
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        return headerView
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if !CAUtils.isiPhone(){
            return 300
        }else{
            return 100
        }
    }
}
