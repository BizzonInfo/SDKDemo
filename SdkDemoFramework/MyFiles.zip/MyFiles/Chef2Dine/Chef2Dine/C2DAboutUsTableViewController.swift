//
//  C2DAboutUsTableViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/20/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DAboutUsTableViewController: UITableViewController {

    @IBOutlet var imageViewRestaurantLogo: UIImageView!
    @IBOutlet var labelRestaurantName: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        CAUtils.setBackgroundForTableView(tableView: self.tableView)
        let homeButton = UIBarButtonItem(image: UIImage(named: "Home"), style: .plain, target: self, action: #selector(self.homeButtonPressed))
        self.navigationItem.rightBarButtonItem = homeButton
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.title = "About Us"
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.backgroundColor = .clear
    }
    
    //MARK:- Button Actions
    
    func homeButtonPressed(){
        _ = self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func menuButtonPressed(_ sender: UIButton) {
        let menuPage = self.storyboard?.instantiateViewController(withIdentifier: "MenuListPage") as! C2DMenuListTableViewController
        self.navigationController?.pushViewController(menuPage, animated: true)
    }
}
