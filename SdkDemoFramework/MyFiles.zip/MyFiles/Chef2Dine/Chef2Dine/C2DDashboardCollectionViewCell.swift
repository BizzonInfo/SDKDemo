//
//  C2DDashboardCollectionViewCell.swift
//  Chef2Dine
//
//  Created by Bon User on 1/19/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DDashboardCollectionViewCell: UICollectionViewCell {
    @IBOutlet var imageViewMenu: UIImageView!
    
    @IBOutlet var labelMenuTitle: MAGlowingLabel!
    
    func customizeCellWithDetails(menuTitle:String){
        self.layoutIfNeeded()
        
        self.layer.borderColor = UIColor.black.cgColor
        self.layer.borderWidth = 1.0
        
        self.labelMenuTitle.textColor = UIColor.white//CAUtils.getColorFromHexString("FF0000")
        self.labelMenuTitle.text = menuTitle
//        self.imageViewMenu.setImageWith(menuTitle, color: CAUtils.getRandomColor(), circular: true)
        self.imageViewMenu.image = UIImage(named: menuTitle)
    }
}
