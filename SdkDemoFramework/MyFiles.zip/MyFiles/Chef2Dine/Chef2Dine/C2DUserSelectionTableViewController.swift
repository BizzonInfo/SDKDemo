//
//  C2DUserSelectionTableViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/20/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit
import Alamofire

class C2DUserSelectionTableViewController: UITableViewController ,UITextFieldDelegate{

    @IBOutlet var labelCafeName: UILabel!
    
    @IBOutlet var imageViewCafeImage: UIImageView!
    
    @IBOutlet var textUserName: JJMaterialTextfield!
    @IBOutlet var textPassword: JJMaterialTextfield!
    
    @IBOutlet var loginPopUpView: UIView!
    
    var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.dark)
    var blurEffectView = UIVisualEffectView()

    var userTypeSelected = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        CAUtils.setBackgroundForTableView(tableView: self.tableView)
        self.labelCafeName.text = "\(UserDefaults.standard.value(forKey: CAFENAME)!)"
        
        self.loginPopUpView.backgroundColor = UIColor.clear
        self.loginPopUpView.layer.borderColor = UIColor.red.cgColor
        self.loginPopUpView.layer.borderWidth = 1.0
        
        textPassword.textColor = .white
        textUserName.textColor = .white
        
        textUserName.tag = 1
        textPassword.tag = 2
        
        textUserName.returnKeyType = .next
        textPassword.returnKeyType = .done
        
        textUserName.delegate = self
        textPassword.delegate = self
        
        textUserName.keyboardType = .emailAddress
        textPassword.isSecureTextEntry = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.backgroundColor = .clear
    }
    
    //MARK:- Button Action
    
    @IBAction func customerSelected(_ sender: UIButton) {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        delegate.initializeWaiterView()
    }
    
    @IBAction func waiterSelected(_ sender: UIButton) {
        self.userTypeSelected = "waiter"
        
        self.textUserName.text = ""
        self.textPassword.text = ""
        
        self.showLoginPopUp()
        self.blur()
        self.animateIn()
    }
    
    @IBAction func chefSelected(_ sender: UIButton) {
        self.userTypeSelected = "chef"
        
        self.textUserName.text = ""
        self.textPassword.text = ""
        
        self.showLoginPopUp()
        self.blur()
        self.animateIn()
        
    }
    @IBAction func loginPressed(_ sender: UIButton) {
        self.loginAPICall()
    }
    
    func loginAPICall(){
        CAUtils.showLoadingViewWithTitle("Loading...")
        let arrayValues = ["admin","admin@123","password",self.textPassword.text!,self.textUserName.text!]
        let arraykeys = ["client_id","client_secret","grant_type","password","username"]
        let dicData = NSDictionary(objects: arrayValues, forKeys: arraykeys as [NSCopying])
        _ = Alamofire.request(adminBaseURL+"token", method: .post, parameters: dicData as? Parameters, encoding: JSONEncoding.default, headers: [:]).responseJSON(completionHandler: { (response) in
            if let result = response.result.value{
                let dictJSON = result as! NSDictionary
                if response.response?.statusCode == 200{
                    self.getUserDetails(access_token: "\(dictJSON["access_token"]!)")
                    CAUtils.removeLoadingView(nil)
                }else{
                    CAUtils.removeLoadingView(nil)
                    CAUtils.showAlertViewControllerWithTitle("Some error occured, Try again later", message: response.result.error?.localizedDescription, cancelButtonTitle: "OK")
                }
            }
            else{
                CAUtils.removeLoadingView(nil)
                CAUtils.showAlertViewControllerWithTitle("Some error occured, Try again later", message: response.result.error?.localizedDescription, cancelButtonTitle: "OK")
            }
        })
    }
    
    func getUserDetails(access_token:String){
        let dicHeaderDetails = NSDictionary(objects: ["Bearer "+access_token], forKeys: ["Authorization" as NSCopying])
        _ = Alamofire.request(adminBaseURL+"token", method: .get, parameters: nil, encoding: JSONEncoding.default, headers: dicHeaderDetails as? HTTPHeaders).responseJSON(completionHandler: { (response) in
            if let result = response.result.value{
                let dictJSON = result as! NSDictionary
                if response.response?.statusCode == 200{
                    if "\(dictJSON["userable_type"]!)" == "waiter"{
                        UserDefaults.standard.setValue("\(dictJSON["userable_type"]!)", forKey: USERABLE_TYPE)
                        let delegate = UIApplication.shared.delegate as! AppDelegate
                        delegate.initializeWaiterView()
                    }else if "\(dictJSON["userable_type"]!)" == "chef"{
                        UserDefaults.standard.setValue("\(dictJSON["userable_type"]!)", forKey: USERABLE_TYPE)
                        let delegate = UIApplication.shared.delegate as! AppDelegate
                        delegate.initializeChefView()
                    }
                    CAUtils.removeLoadingView(nil)
                }else{
                    CAUtils.removeLoadingView(nil)
                    CAUtils.showAlertViewControllerWithTitle("Some error occured, Try again later", message: response.result.error?.localizedDescription, cancelButtonTitle: "OK")
                }
            }
            else{
                CAUtils.removeLoadingView(nil)
                CAUtils.showAlertViewControllerWithTitle("Some error occured, Try again later", message: response.result.error?.localizedDescription, cancelButtonTitle: "OK")
            }
        })
    }
    //MARK:- Textfield Delegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let nextTag = textField.tag+1
        let nextResponder = textField.superview?.viewWithTag(nextTag)
        if nextResponder != nil{
            nextResponder?.becomeFirstResponder()
        }else{
            textField.resignFirstResponder()
        }
        return false
    }

    //MARK:- iPopUP Functions
    
    override func viewDidAppear(_ animated: Bool) {
        loginPopUpView.setNeedsFocusUpdate()
    }
    override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let rootView = delegate.window?.rootViewController?.view
        
        loginPopUpView.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: (rootView?.frame.width)! - 50, height: 285))
        loginPopUpView.center = view.center
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches , with:event)
        if touches.first != nil{
            removeBlur()
            animateOut()
        }
    }
    
    func touchesView(){//tapAction
        removeBlur()
        animateOut()
    }
       
    override func viewWillDisappear(_ animated: Bool) {
        removeBlur()
        animateOut()
    }
    
    public func removeBlur() {
        blurEffectView.removeFromSuperview()
    }
    
    func showLoginPopUp(){
        if !CAUtils.isiPhone(){
            loginPopUpView.frame.origin.x = 0
            loginPopUpView.frame.origin.y = 0
        }
        else{
            let delegate = UIApplication.shared.delegate as! AppDelegate
            let rootView = delegate.window?.rootViewController?.view
            if GlobalVariables.sharedManager.rotated() == true{
                loginPopUpView.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: (rootView?.frame.width)! - 50, height: 146))
            }
            else {
                loginPopUpView.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: (rootView?.frame.width)! - 50, height: 146))
            }
        }
        loginPopUpView.layer.cornerRadius = 5 //make oval view edges
    }
    
    func blur(){
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let rootView = delegate.window?.rootViewController?.view
        blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = (rootView?.bounds)!
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight] // for supporting device rotation
        rootView?.addSubview(blurEffectView)
        
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(self.touchesView))
        singleTap.numberOfTapsRequired = 1
        self.blurEffectView.addGestureRecognizer(singleTap)
    }
    
    func animateIn() {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let rootView = delegate.window?.rootViewController?.view
        //        self.view.addSubview(loginPopUpView)
        rootView?.addSubview(loginPopUpView)
        loginPopUpView.center = (rootView?.center)!
        loginPopUpView.transform = CGAffineTransform.init(scaleX: 1.3, y: 1.3)
        loginPopUpView.alpha = 0
        UIView.animate(withDuration: 0.4) {
            self.loginPopUpView.alpha = 1
            self.loginPopUpView.transform = CGAffineTransform.identity
        }
    }
    
    public func animateOut () {
        UIView.animate(withDuration: 0.3, animations: {
            self.loginPopUpView.transform = CGAffineTransform.init(scaleX: 2.0, y: 2.0)
            self.loginPopUpView.alpha = 0
        }) { (success:Bool) in
            self.loginPopUpView.transform = CGAffineTransform.init(scaleX: 1.0, y: 1.0)
            self.loginPopUpView.removeFromSuperview()
        }
    }

}
