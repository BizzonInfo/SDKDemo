//
//  C2DProcessedBillTableViewCell.swift
//  Chef2Dine
//
//  Created by Bon User on 1/19/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DProcessedBillTableViewCell: UITableViewCell {

    @IBOutlet var imageViewStatus: UIImageView!
    @IBOutlet var labelBillNumber: UILabel!
    @IBOutlet var labelDate: UILabel!
    @IBOutlet var labelAmount: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func customizeCellWithDetails(billNumber:String,billDate:String,billAmount:String,status:String){
        self.labelBillNumber.text = billNumber
        self.labelDate.text = billDate
        self.labelAmount.text = billAmount
        
        self.imageViewStatus.image = UIImage(named: status)
    }
}
