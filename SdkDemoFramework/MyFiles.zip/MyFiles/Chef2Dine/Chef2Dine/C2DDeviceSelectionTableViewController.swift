//
//  C2DDeviceSelectionTableViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/23/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit
import Alamofire

class C2DDeviceSelectionTableViewController: UITableViewController ,UITextFieldDelegate {

    @IBOutlet var deviceEntryPopUpView: UIView!
    @IBOutlet var textDeviceId: JJMaterialTextfield!
    @IBOutlet var textDeviceSecret: JJMaterialTextfield!
    
    var dicCafeDetails = NSDictionary()
    var arrayDeviceDetails = NSMutableArray()
    
    var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.dark)
    var blurEffectView = UIVisualEffectView()
    
    var device_id = ""
    var uniqueDeviceId = CAUtils.getDeviceUniqueId()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.hidesBackButton = true
        let backButton = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(self.backAction))
        self.navigationItem.rightBarButtonItem = backButton
        self.deviceEntryPopUpView.layer.borderColor = UIColor.red.cgColor
        self.deviceEntryPopUpView.layer.borderWidth = 1.0
        self.populateDevices()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
        self.navigationController?.navigationBar.layer.cornerRadius = 10.0
    }
    
    func backAction(){
        UIView.beginAnimations("Flip", context: nil)
        UIView.setAnimationDuration(1.0)
        UIView.setAnimationCurve(UIViewAnimationCurve.easeInOut)
        UIView.setAnimationTransition(UIViewAnimationTransition.flipFromLeft, for: (self.navigationController?.view)!, cache: false)
        _ = self.navigationController?.popViewController(animated: true)
        UIView.commitAnimations()
    }
    
    func populateDevices(){
        let arrayDevices = self.dicCafeDetails["devices"] as! NSArray
        if arrayDevices.count > 0 {
            self.arrayDeviceDetails.removeAllObjects()
            for item in arrayDevices{
                let dicDevice = item as! NSDictionary
                self.arrayDeviceDetails.add(dicDevice)
            }
            self.tableView.reloadData()
        }else{
            CAUtils.showToastWithTitle("No idle devices for the Cafe \(self.dicCafeDetails["name"]!)")
        }
    }
    
    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.arrayDeviceDetails.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DeviceList", for: indexPath)
        let dicData = self.arrayDeviceDetails[indexPath.row] as! NSDictionary
        cell.textLabel?.textColor = .white
        cell.textLabel?.text = "\(dicData["name"]!)"
        cell.layer.shadowColor = UIColor.red.cgColor
        cell.layer.shadowOffset = CGSize(width: 2, height: 2)
        let shadowFrame = CGRect(x: 0, y: cell.frame.height-1, width: cell.frame.width, height: 3)
        let shadowPath = UIBezierPath(rect: shadowFrame).cgPath
        cell.layer.shadowPath = shadowPath
        cell.layer.shadowOpacity = 1.0
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //show device sync option
        
        let dicData = self.arrayDeviceDetails[indexPath.row] as! NSDictionary
        device_id = "\(dicData["id"]!)"
        self.viewDeviceSyncOption()
        blur()
        animateIn()
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.backgroundColor = .clear
    }
    
    func syncDevice(){
        CAUtils.showLoadingViewWithTitle("Loading...")
        let arrayValues = ["admin","admin@123","client_credentials"]
        let arraykeys = ["client_id","client_secret","grant_type"]
        let dicData = NSDictionary(objects: arrayValues, forKeys: arraykeys as [NSCopying])
        _ = Alamofire.request(adminBaseURL+"token", method: .post, parameters: dicData as? Parameters, encoding: JSONEncoding.default, headers: [:]).responseJSON(completionHandler: { (response) in
            if let result = response.result.value{
                let dictJSON = result as! NSDictionary
                self.getDeviceSyncDetails(access_token: "\(dictJSON["access_token"]!)")
                CAUtils.removeLoadingView(nil)
            }
            else{
                CAUtils.removeLoadingView(nil)
                CAUtils.showAlertViewControllerWithTitle("Some error occured, Try again later", message: response.result.error?.localizedDescription, cancelButtonTitle: "OK")
            }
        })
    }
    
    func getDeviceSyncDetails(access_token:String){
        let arrayValues = [device_id,self.textDeviceId.text!,self.textDeviceSecret.text!,uniqueDeviceId]
        let arraykeys = ["id","code","secret","unique_device_id"]
        let dicData = NSDictionary(objects: arrayValues, forKeys: arraykeys as [NSCopying])
        print(dicData)
        let dicHeaderDetails = NSDictionary(objects: ["Bearer "+access_token], forKeys: ["Authorization" as NSCopying])
        _ = Alamofire.request(adminBaseURL+"api-device-connect", method: .post, parameters: dicData as? Parameters, encoding: JSONEncoding.default, headers: dicHeaderDetails as? HTTPHeaders).responseJSON(completionHandler: { (response) in
            if let result = response.result.value{
                let dictJSON = result as! NSDictionary
                if response.response?.statusCode == 200{
                    let dicDeviceDetails = dictJSON["device_details"] as! NSDictionary
                    UserDefaults.standard.setValue("\(dictJSON["handshake"]!)", forKey: deviceHandShake)
                    UserDefaults.standard.setValue("\(dicDeviceDetails["id"]!)", forKey: deviceId)
                    UserDefaults.standard.setValue("\(dicDeviceDetails["code"]!)", forKey: deviceCode)
                    let delegate = UIApplication.shared.delegate as! AppDelegate
                    delegate.initializeUserSelectionView()
                    CAUtils.removeLoadingView(nil)
                }else{
                    CAUtils.removeLoadingView(nil)
                    CAUtils.showAlertViewControllerWithTitle("Some error occured, Try again later", message: response.result.error?.localizedDescription, cancelButtonTitle: "OK")
                }
            }
            else{
                CAUtils.removeLoadingView(nil)
                CAUtils.showAlertViewControllerWithTitle("Some error occured, Try again later", message: response.result.error?.localizedDescription, cancelButtonTitle: "OK")
            }
        })
    }
    
    /*
     "device_status"="active"
     "device_status"="Authorization failed"
     
     */
    
    //MARK:- Textfield Delegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let nextTag = textField.tag+1
        let nextResponder = textField.viewWithTag(nextTag)
        if nextResponder != nil{
            nextResponder?.becomeFirstResponder()
        }else{
            textField.resignFirstResponder()
        }
        return false
    }
    
    //MARK:- iPopUP Functions
    
    override func viewDidAppear(_ animated: Bool) {
        deviceEntryPopUpView.setNeedsFocusUpdate()
    }
    override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let rootView = delegate.window?.rootViewController?.view

        deviceEntryPopUpView.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: (rootView?.frame.width)! - 50, height: 285))
        deviceEntryPopUpView.center = view.center
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches , with:event)
        if touches.first != nil{
            removeBlur()
            animateOut()
        }
    }
    
    func touchesView(){//tapAction
        removeBlur()
        animateOut()
    }
    @IBAction func dismissPopUp(_ sender: AnyObject) {
//        let delegate = UIApplication.shared.delegate as! AppDelegate
//        let userSelection = self.storyboard?.instantiateViewController(withIdentifier: "UserSelectionNavigation") as! C2DUserSelectionNavigationViewController
//        delegate.window?.rootViewController = userSelection
//        delegate.window?.makeKeyAndVisible()
        self.syncDevice()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        removeBlur()
        animateOut()
    }
    
    public func removeBlur() {
        blurEffectView.removeFromSuperview()
    }
    
    func viewDeviceSyncOption(){
        if !CAUtils.isiPhone(){
            deviceEntryPopUpView.frame.origin.x = 0
            deviceEntryPopUpView.frame.origin.y = 0
        }
        else{
            let delegate = UIApplication.shared.delegate as! AppDelegate
            let rootView = delegate.window?.rootViewController?.view
            if GlobalVariables.sharedManager.rotated() == true{
                deviceEntryPopUpView.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: (rootView?.frame.width)! - 50, height: 122))
            }
            else {
                deviceEntryPopUpView.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: (rootView?.frame.width)! - 50, height: 122))
            }
        }
        deviceEntryPopUpView.layer.cornerRadius = 5 //make oval view edges
    }
    
    func blur(){
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let rootView = delegate.window?.rootViewController?.view
        blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = (rootView?.bounds)!
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight] // for supporting device rotation
        rootView?.addSubview(blurEffectView)
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(self.touchesView))
        singleTap.numberOfTapsRequired = 1
        self.blurEffectView.addGestureRecognizer(singleTap)
    }
    
    func animateIn(){
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let rootView = delegate.window?.rootViewController?.view
//        self.view.addSubview(deviceEntryPopUpView)
        rootView?.addSubview(deviceEntryPopUpView)
        deviceEntryPopUpView.center = (rootView?.center)!
        deviceEntryPopUpView.transform = CGAffineTransform.init(scaleX: 1.3, y: 1.3)
        deviceEntryPopUpView.alpha = 0
        UIView.animate(withDuration: 0.4) {
            self.deviceEntryPopUpView.alpha = 1
            self.deviceEntryPopUpView.transform = CGAffineTransform.identity
        }
    }
    
    public func animateOut() {
        UIView.animate(withDuration: 0.3, animations: {
            self.deviceEntryPopUpView.transform = CGAffineTransform.init(scaleX: 2.0, y: 2.0)
            self.deviceEntryPopUpView.alpha = 0
        }) { (success:Bool) in
            self.deviceEntryPopUpView.transform = CGAffineTransform.identity
            self.deviceEntryPopUpView.removeFromSuperview()
        }
    }
}
