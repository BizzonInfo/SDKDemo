//
//  C2DDeviceHandshakeViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/24/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit
import Alamofire

class C2DDeviceHandshakeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if let device_id = UserDefaults.standard.value(forKey: deviceId) as? String{
            let device_code = UserDefaults.standard.value(forKey: deviceCode) as! String
            let deviceHandshake = UserDefaults.standard.value(forKey: deviceHandShake) as! String
            self.checkDeviceAlreadySynced(device_id: device_id, code: device_code, handshake: deviceHandshake)
        }else{
            let delegate = UIApplication.shared.delegate as! AppDelegate
            delegate.initializeCafeLoginView()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func checkDeviceAlreadySynced(device_id:String,code:String,handshake:String){
        let arrayValues = ["admin","admin@123","client_credentials"]
        let arraykeys = ["client_id","client_secret","grant_type"]
        let dicData = NSDictionary(objects: arrayValues, forKeys: arraykeys as [NSCopying])
        _ = Alamofire.request(adminBaseURL+"token", method: .post, parameters: dicData as? Parameters, encoding: JSONEncoding.default, headers: [:]).responseJSON(completionHandler: { (response) in
            if let result = response.result.value{
                let dictJSON = result as! NSDictionary
                self.getSyncedDeviceDetails(device_id: device_id, code: code, handshake: handshake, access_token: "\(dictJSON["access_token"]!)")
//                CAUtils.removeLoadingView(nil)
            }
            else{
                CAUtils.removeLoadingView(nil)
                CAUtils.showAlertViewControllerWithTitle("Some error occured, Try again later", message: response.result.error?.localizedDescription, cancelButtonTitle: "OK")
            }
        })
    }
    
    func getSyncedDeviceDetails(device_id:String,code:String,handshake:String,access_token:String){
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let arrayValues = [device_id,code,handshake]
        let arraykeys = ["id","code","handshake"]
        let dicData = NSDictionary(objects: arrayValues, forKeys: arraykeys as [NSCopying])
        let dicHeaderDetails = NSDictionary(objects: ["Bearer "+access_token], forKeys: ["Authorization" as NSCopying])
        CAUtils.showLoadingViewWithTitle("Loading...")
        _ = Alamofire.request(adminBaseURL+"check-device-handshake", method: .post, parameters: dicData as? Parameters, encoding: JSONEncoding.default, headers: dicHeaderDetails as? HTTPHeaders).responseJSON(completionHandler: { (response) in
            if let result = response.result.value{
                let dictJSON = result as! NSDictionary
                if "\(dictJSON["device_status"]!)" == "active"{
                    delegate.initializeUserSelectionView()
                }else if "\(dictJSON["device_status"]!)" == "Authorization failed"{
                    delegate.initializeCafeLoginView()
                }
                else{
                    CAUtils.showAlertViewControllerWithTitle("Some error occured, Try again later", message: response.result.error?.localizedDescription, cancelButtonTitle: "OK")
                }
                CAUtils.removeLoadingView(nil)
            }
            else{
                CAUtils.removeLoadingView(nil)
                CAUtils.showAlertViewControllerWithTitle("Some error occured, Try again later", message: response.result.error?.localizedDescription, cancelButtonTitle: "OK")
            }
        })

    }
}
