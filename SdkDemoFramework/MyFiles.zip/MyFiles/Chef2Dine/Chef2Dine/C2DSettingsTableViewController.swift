//
//  C2DSettingsTableViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/20/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DSettingsTableViewController: UITableViewController,LBZSpinnerDelegate {

    var arraySettingsTitle = ["Set Default Table","Logout"]
    var arrayTableList = ["Diamond","Ruby","Pearl"]
    
    @IBOutlet var spinnerTableList: LBZSpinner!
    @IBOutlet var buttonSubmit: UIButton!
    @IBOutlet var popUpTableSelection: UIView!
    
    var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.dark)
    var blurEffectView = UIVisualEffectView()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.popUpTableSelection.backgroundColor = .clear
        
        popUpTableSelection.layer.borderColor = UIColor.red.cgColor
        popUpTableSelection.layer.borderWidth = 1.0
        
        NotificationCenter.default.addObserver(forName: NSNotification.Name.UIDeviceOrientationDidChange, object: nil, queue: nil) { (notification) in
            self.tableView.reloadData()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.title = "Settings"
    }
    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.arraySettingsTitle.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "settingsCell", for: indexPath)

        cell.textLabel?.text = self.arraySettingsTitle[indexPath.row]
        
        cell.layer.shadowColor = UIColor.red.cgColor
        cell.layer.shadowOffset = CGSize(width: 1, height: 0)
        let shadowFrame = CGRect(x: 0, y: cell.frame.height-1, width: cell.frame.width, height: 2)
        let shadowPath = UIBezierPath(rect: shadowFrame).cgPath
        cell.layer.shadowPath = shadowPath
        cell.layer.shadowOpacity = 0.5

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            spinnerTableList.updateList(list: self.arrayTableList)
            spinnerTableList.delegate = self
            
            if self.spinnerTableList.selectedIndex == LBZSpinner.INDEX_NOTHING{
                self.spinnerTableList.changeSelectedIndex(index: 0)
            }
            
            showTableSelectionPopUp()
            blur()
            animateIn()
            
        }else if indexPath.row == 1 {
            let cell = self.tableView.cellForRow(at: indexPath)
            let logoutAlert = UIAlertController(title: "Do you want to logout?", message: nil, preferredStyle: .actionSheet)
            logoutAlert.addAction(UIAlertAction(title: "Logout", style: .destructive, handler: { (action) in
                let delegate = UIApplication.shared.delegate as! AppDelegate
                delegate.logout()
            }))
            logoutAlert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { (action) in
                self.dismiss(animated: true, completion: nil)
            }))
            self.present(logoutAlert, animated: true, completion: nil)
            
            if !CAUtils.isiPhone(){
                let popOver = logoutAlert.popoverPresentationController
                popOver?.sourceView = cell
                popOver?.sourceRect = (cell?.bounds)!
            }
        }
    }
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.backgroundColor = .clear
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if !CAUtils.isiPhone(){
            return 100
        }else{
            return 60
        }
    }
    
    //MARK:- Button Actions
        
    @IBAction func submitButtonPressed(_ sender: UIButton) {
        //call api
        removeBlur()
        animateOut()
    }
    
    //MARK:- Spinner Delegate
    
    func spinnerChoose(spinner: LBZSpinner, index: Int, value: String) {
        
    }
    
    //MARK:- iPopUP Functions
    
    override func viewDidAppear(_ animated: Bool) {
        popUpTableSelection.setNeedsFocusUpdate()
    }
    override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        popUpTableSelection.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: view.frame.width - 50, height: 120))
        popUpTableSelection.center = view.center
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches , with:event)
        if touches.first != nil{
            removeBlur()
            animateOut()
        }
    }
    
    func touchesView(){//tapAction
        removeBlur()
        animateOut()
    }
    @IBAction func dismissPopUp(_ sender: AnyObject) {
        removeBlur()
        animateOut()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        removeBlur()
        animateOut()
    }
    
    public func removeBlur() {
        blurEffectView.removeFromSuperview()
    }
    
    func showTableSelectionPopUp(){
        if !CAUtils.isiPhone(){
            popUpTableSelection.frame.origin.x = 0
            popUpTableSelection.frame.origin.y = 0
        }
        else{
            if GlobalVariables.sharedManager.rotated() == true{
                popUpTableSelection.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: view.frame.width - 50, height: 120))
            }
            else {
                popUpTableSelection.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: view.frame.width - 50, height: 120))
            }
        }
        popUpTableSelection.layer.cornerRadius = 5 //make oval view edges
    }
    
    func blur(){
        blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight] // for supporting device rotation
        view.addSubview(blurEffectView)
        
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(self.touchesView))
        singleTap.numberOfTapsRequired = 1
        self.blurEffectView.addGestureRecognizer(singleTap)
    }
    
    func animateIn() {
        self.view.addSubview(popUpTableSelection)
        popUpTableSelection.center = self.view.center
        popUpTableSelection.transform = CGAffineTransform.init(scaleX: 1.3, y: 1.3)
        popUpTableSelection.alpha = 0
        UIView.animate(withDuration: 0.4) {
            self.popUpTableSelection.alpha = 1
            self.popUpTableSelection.transform = CGAffineTransform.identity
        }
    }
    
    public func animateOut () {
        UIView.animate(withDuration: 0.3, animations: {
            self.popUpTableSelection.transform = CGAffineTransform.init(scaleX: 2.0, y: 2.0)
            self.popUpTableSelection.alpha = 0
        }) { (success:Bool) in
            self.popUpTableSelection.transform = CGAffineTransform.init(scaleX: 1.0, y: 1.0)
            self.popUpTableSelection.removeFromSuperview()
        }
    }
}
