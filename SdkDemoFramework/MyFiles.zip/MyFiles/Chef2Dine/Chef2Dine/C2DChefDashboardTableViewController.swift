//
//  C2DChefDashboardTableViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/20/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DChefDashboardTableViewController: UITableViewController {

    var logoutButton = UIBarButtonItem()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        logoutButton = UIBarButtonItem(image: UIImage(named:"Logout"), style: .plain, target: self, action: #selector(self.logoutButtonAction))
        self.navigationItem.rightBarButtonItem = logoutButton
        
        NotificationCenter.default.addObserver(forName: NSNotification.Name.UIDeviceOrientationDidChange, object: nil, queue: nil) { (notification) in
            self.tableView.reloadData()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.title = "Orders"
    }
    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 5
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "recepieList", for: indexPath) as! C2DChefOrderListTableViewCell
        
        cell.customizeCellWithDetails(recipieName: "Pancakes", status: "Pending", quantity: "3", tableName: "Diamond", remarks: "No Remarks", orderNumber: "\(indexPath.row+1)", orderDate: CAUtils.getStringFromDate(Date()))
        
        cell.layer.shadowColor = UIColor.red.cgColor
        cell.layer.shadowOffset = CGSize(width: 1, height: 0)
        let shadowFrame = CGRect(x: 0, y: cell.frame.height-1, width: cell.frame.width, height: 2)
        let shadowPath = UIBezierPath(rect: shadowFrame).cgPath
        cell.layer.shadowPath = shadowPath
        cell.layer.shadowOpacity = 0.5

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var alertTitle = ""
        var alertMessage = ""
        alertTitle = "Initiate Order Processing"
        alertMessage = "Are you sure to start the processing of this item?"
        
        let statusAlert = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: .alert)
        let startPreparing = UIAlertAction(title: "Start preparing", style: .default) { (action) in
            
        }
        let finishCooking = UIAlertAction(title: "Finish", style: .default) { (action) in
            
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
            
        }
        statusAlert.addAction(startPreparing)
        statusAlert.addAction(cancelAction)
        self.present(statusAlert, animated: true, completion: nil)
        
        let cell = self.tableView.cellForRow(at: indexPath)
        if !CAUtils.isiPhone(){
            let popOver = statusAlert.popoverPresentationController
            popOver?.sourceView = cell
            popOver?.sourceRect = (cell?.bounds)!
        }
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.backgroundColor = .clear
    }
    
    //MARK:- Button Actions
    
    func logoutButtonAction(){
        let logoutAlert = UIAlertController(title: "Do you want to logout?", message: nil, preferredStyle: .actionSheet)
        logoutAlert.addAction(UIAlertAction(title: "Logout", style: .destructive, handler: { (action) in
            let delegate = UIApplication.shared.delegate as! AppDelegate
            delegate.logout()
        }))
        logoutAlert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { (action) in
            self.dismiss(animated: true, completion: nil)
        }))
        self.present(logoutAlert, animated: true, completion: nil)
        
        if !CAUtils.isiPhone(){
            let popOver = logoutAlert.popoverPresentationController
            popOver?.barButtonItem = self.logoutButton
        }
    }
}
