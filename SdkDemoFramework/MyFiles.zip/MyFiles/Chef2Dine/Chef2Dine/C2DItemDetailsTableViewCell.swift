//
//  C2DItemDetailsTableViewCell.swift
//  Chef2Dine
//
//  Created by Bon User on 1/19/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DItemDetailsTableViewCell: UITableViewCell {

    @IBOutlet var imageViewItemImage: UIImageView!
    @IBOutlet var labelItemName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func customizeCellWithDetails(itemName:String,itemImageName:String){
        self.imageViewItemImage.image = UIImage(named: itemImageName)
        self.labelItemName.text = itemName
    }
}
