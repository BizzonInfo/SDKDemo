//
//  C2DOrderDetailsTableViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/21/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DOrderDetailsTableViewController: UITableViewController {

    @IBOutlet var tableViewHeader: UIView!
    
    var moreButton = UIBarButtonItem()
    
    var isPendingPage = Bool()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        moreButton = UIBarButtonItem(image: UIImage(named:"MoreIcon"), style: .plain, target: self, action: #selector(self.moreButtonAction))
        self.navigationItem.rightBarButtonItem = moreButton
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 5
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "orderDetailsList", for: indexPath) as! C2DOrderDetailsTableViewCell
        
        
        
        cell.layer.shadowColor = UIColor.red.cgColor
        cell.layer.shadowOffset = CGSize(width: 1, height: 0)
        let shadowFrame = CGRect(x: 0, y: cell.frame.height-1, width: cell.frame.width, height: 2)
        let shadowPath = UIBezierPath(rect: shadowFrame).cgPath
        cell.layer.shadowPath = shadowPath
        cell.layer.shadowOpacity = 0.5
        
        return cell
    }

    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return tableViewHeader
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 156
    }
    //MARK:- Button Actions
    
    func moreButtonAction(){
        let moreActionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        let home = UIAlertAction(title: "Home", style: .default) { (action) in
            _ = self.navigationController?.popToRootViewController(animated: true)
        }
        let editOrder = UIAlertAction(title: "Edit Order", style: .default) { (action) in
            let editOrder = self.storyboard?.instantiateViewController(withIdentifier: "editOrderPage") as! C2DEditOrderTableViewController
            self.navigationController?.pushViewController(editOrder, animated: true)
        }
        let cancelOrder = UIAlertAction(title: "Cancel Order", style: .default) { (action) in
            let orderAlert = UIAlertController(title: nil, message: "Are you sure to cancel this order?", preferredStyle: .alert)
            let confirmAction = UIAlertAction(title: "Yes", style: .destructive) { (action) in
                
            }
            let cancelAction = UIAlertAction(title: "No", style: .cancel) { (action) in
                self.dismiss(animated: true, completion: nil)
            }
            orderAlert.addAction(confirmAction)
            orderAlert.addAction(cancelAction)
            self.present(orderAlert, animated: true, completion: nil)
        }
        let checkBill = UIAlertAction(title: "Check Bill", style: .default) { (action) in
            
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
            self.dismiss(animated: true, completion: nil)
        }
        moreActionSheet.addAction(home)
        if isPendingPage{
            moreActionSheet.addAction(editOrder)
            moreActionSheet.addAction(cancelOrder)
        }else{
            moreActionSheet.addAction(checkBill)
        }
        moreActionSheet.addAction(cancelAction)
        
        self.present(moreActionSheet, animated: true, completion: nil)
        if !CAUtils.isiPhone(){
            let popOver = moreActionSheet.popoverPresentationController
            popOver?.barButtonItem = moreButton
        }
    }
}
