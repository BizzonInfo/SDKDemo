//
//  C2DChefOrderListTableViewCell.swift
//  Chef2Dine
//
//  Created by Bon User on 1/21/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DChefOrderListTableViewCell: UITableViewCell {

    @IBOutlet var labelRecipieName: UILabel!
    @IBOutlet var labelStatus: UILabel!
    @IBOutlet var labelQuantity: UILabel!
    @IBOutlet var labelTableName: UILabel!
    
    @IBOutlet var textViewRemarks: UITextView!
    
    @IBOutlet var labelOrderNumber: UILabel!
    @IBOutlet var labelOrderDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func customizeCellWithDetails(recipieName:String,status:String,quantity:String,tableName:String,remarks:String,orderNumber:String,orderDate:String){
        
        self.textViewRemarks.layer.borderColor = UIColor.red.cgColor
        self.textViewRemarks.layer.borderWidth = 1.0
        
        self.labelRecipieName.text = recipieName
        self.labelStatus.text = status
        self.labelQuantity.text = quantity
        self.labelTableName.text = tableName
        
        self.textViewRemarks.text = remarks
        
        self.labelOrderNumber.text = "Order # "+orderNumber
        self.labelOrderDate.text = orderDate
    }
}
