//
//  C2DDashboardCollectionViewController.swift
//  Chef2Dine
//
//  Created by Bon User on 1/19/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

private let reuseIdentifier = "DashboardCell"

class C2DDashboardCollectionViewController: UICollectionViewController,ASJCollectionViewFillLayoutDelegate {

    var layout = ASJCollectionViewFillLayout()
    
    var arrayMenuDashboard = [String]()
    
    var refreshController = UIRefreshControl()
    
    var isCustomerMode = true
    
    var blurEffect = UIBlurEffect(style: UIBlurEffectStyle.dark)
    var blurEffectView = UIVisualEffectView()

    var moreButton = UIBarButtonItem()
    
    @IBOutlet var popViewOrderCategories: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
//         self.clearsSelectionOnViewWillAppear = false

        self.refreshController.tintColor = CAUtils.getColorFromHexString(materialRedColor)
        self.refreshController.addTarget(self, action: #selector(self.refreshInitiated), for: .valueChanged)
        self.collectionView?.addSubview(self.refreshController)
        self.collectionView?.alwaysBounceVertical=true

        self.setupCollectionViewData(arrayData: ["Menu","Feedback","Orders","About Us","Bills","Settings"])
        self.setupLayout()
        
        let customerMode = UIBarButtonItem(image: UIImage(named:"Lock"), style: .plain, target: self, action: #selector(self.customerMode))
        self.navigationItem.leftBarButtonItem = customerMode
        
        moreButton = UIBarButtonItem(image: UIImage(named:"MoreIcon"), style: .plain, target: self, action: #selector(self.moreButtonAction))
        self.navigationItem.rightBarButtonItem = moreButton
        
        popViewOrderCategories.layer.borderColor = UIColor.red.cgColor
        popViewOrderCategories.layer.borderWidth = 1.0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.title = "Home"
    }
    
    func setupCollectionViewData(arrayData : [String]){
        arrayMenuDashboard = arrayData
        self.collectionView?.reloadData()
    }
    func setupLayout(){
        self.layout.delegate = self
        self.layout.direction = ASJCollectionViewFillLayoutDirection.vertical
        self.collectionView?.collectionViewLayout = self.layout
    }

    func customerMode(){
        if isCustomerMode == true{
            isCustomerMode = false
            let waiterMode = UIBarButtonItem(image: UIImage(named:"UnLock"), style: .plain, target: self, action: #selector(self.customerMode))
            self.navigationItem.leftBarButtonItem = waiterMode
            self.setupCollectionViewData(arrayData: ["Menu","Feedback","Orders","About Us"])
        }else{
            isCustomerMode = true
            let customerMode = UIBarButtonItem(image: UIImage(named:"Lock"), style: .plain, target: self, action: #selector(self.customerMode))
            self.navigationItem.leftBarButtonItem = customerMode
            self.setupCollectionViewData(arrayData: ["Menu","Feedback","Orders","About Us","Bills","Settings"])
        }
    }
    
    func moreButtonAction(){
        let moreActionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        let logout = UIAlertAction(title: "Logout", style: .default) { (action) in
            self.logoutAction()
        }
        let changeUser = UIAlertAction(title: "Change User", style: .default) { (action) in
            self.logoutAction()
        }
        let aboutUs = UIAlertAction(title: "About Us", style: .default) { (action) in
            let aboutUsPage = self.storyboard?.instantiateViewController(withIdentifier: "AboutUsPage") as! C2DAboutUsTableViewController
            self.navigationController?.pushViewController(aboutUsPage, animated: true)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
            self.dismiss(animated: true, completion: nil)
        }
        moreActionSheet.addAction(logout)
        moreActionSheet.addAction(changeUser)
        moreActionSheet.addAction(aboutUs)
        moreActionSheet.addAction(cancelAction)
        
        self.present(moreActionSheet, animated: true, completion: nil)
        if !CAUtils.isiPhone(){
            let popOver = moreActionSheet.popoverPresentationController
            popOver?.barButtonItem = moreButton
        }
    }
    
    func logoutAction(){
        let logoutAlert = UIAlertController(title: "Do you want to logout?", message: nil, preferredStyle: .actionSheet)
        logoutAlert.addAction(UIAlertAction(title: "Logout", style: .destructive, handler: { (action) in
            let delegate = UIApplication.shared.delegate as! AppDelegate
            delegate.logout()
        }))
        logoutAlert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { (action) in
            self.dismiss(animated: true, completion: nil)
        }))
        self.present(logoutAlert, animated: true, completion: nil)
        
        if !CAUtils.isiPhone(){
            let popOver = logoutAlert.popoverPresentationController
            popOver?.barButtonItem = self.moreButton
        }

    }
    
    func refreshInitiated(){
        self.refreshController.endRefreshing()
        self.collectionView?.reloadData()
    }
    // MARK: UICollectionViewDataSource

    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrayMenuDashboard.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! C2DDashboardCollectionViewCell
        cell.customizeCellWithDetails(menuTitle: self.arrayMenuDashboard[indexPath.row])
    
        return cell
    }

    // MARK: UICollectionViewDelegate

    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            let menuPage = self.storyboard?.instantiateViewController(withIdentifier: "MenuListPage") as! C2DMenuListTableViewController
            self.navigationController?.pushViewController(menuPage, animated: true)
        }else if indexPath.row == 1{
            let feedbackPage = self.storyboard?.instantiateViewController(withIdentifier: "FeedbackPage") as! C2DFeedbackTableViewController
            self.navigationController?.pushViewController(feedbackPage, animated: true)
        }else if indexPath.row == 2{
            viewOrderCategories()
            blur()
            animateIn()
        }else if indexPath.row == 3{
            let aboutUsPage = self.storyboard?.instantiateViewController(withIdentifier: "AboutUsPage") as! C2DAboutUsTableViewController
            self.navigationController?.pushViewController(aboutUsPage, animated: true)
        }else if indexPath.row == 4{
            let processedPage = self.storyboard?.instantiateViewController(withIdentifier: "ProcessedBill") as! C2DProcessedBillTableViewController
            self.navigationController?.pushViewController(processedPage, animated: true)
        }else if indexPath.row == 5{
            let settingsPage = self.storyboard?.instantiateViewController(withIdentifier: "SettingsPage") as! C2DSettingsTableViewController
            self.navigationController?.pushViewController(settingsPage, animated: true)
        }
    }
    
    //MARK:- Button Action
    @IBAction func viewCartPressed(_ sender: UIButton) {
        
    }
    
    @IBAction func onGoingOrdersPressed(_ sender: UIButton) {
        let orderList = self.storyboard?.instantiateViewController(withIdentifier: "OrderList") as! C2DOrderListTableViewController
        orderList.isPendingPage = true
        self.navigationController?.pushViewController(orderList, animated: true)
    }
    
    @IBAction func completedOrdersPressed(_ sender: UIButton) {
        let orderList = self.storyboard?.instantiateViewController(withIdentifier: "OrderList") as! C2DOrderListTableViewController
        orderList.isPendingPage = false
        self.navigationController?.pushViewController(orderList, animated: true)
    }
    
    //MARK:- ASJCollectionView Layout delegates
    
    func numberOfItemsInSide() -> Int {
        if CAUtils.isiPhone(){
            return 2
        }else{
            return 3
        }
    }
    func itemLength() -> CGFloat {
        if CAUtils.isiPhone(){
            return 150
        }else{
            return 300
        }
    }
    func itemSpacing() -> CGFloat {
        return 5
    }
    
    //MARK:- iPopUP Functions
    
    override func viewDidAppear(_ animated: Bool) {
        popViewOrderCategories.setNeedsFocusUpdate()
    }
    override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        popViewOrderCategories.center = view.center
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches , with:event)
        if touches.first != nil{
            removeBlur()
            animateOut()
        }
    }
    @IBAction func dismissPopUp(_ sender: AnyObject) {
        removeBlur()
        animateOut()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        removeBlur()
        animateOut()
    }
    
    public func removeBlur() {
        blurEffectView.removeFromSuperview()
    }
    
    func viewOrderCategories(){
        if !CAUtils.isiPhone(){
            popViewOrderCategories.frame.origin.x = 0
            popViewOrderCategories.frame.origin.y = 0
        }
        else{
            if GlobalVariables.sharedManager.rotated() == true{
                popViewOrderCategories.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: view.frame.width - 50, height: view.frame.height - 10))
            }
            else {
                popViewOrderCategories.frame = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: view.frame.width - 50, height: 140))
            }
        }
        popViewOrderCategories.layer.cornerRadius = 5 //make oval view edges
    }
    
    func blur(){
        blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight] // for supporting device rotation
        view.addSubview(blurEffectView)
    }
    
    func animateIn() {
        self.view.addSubview(popViewOrderCategories)
        popViewOrderCategories.center = self.view.center
        popViewOrderCategories.transform = CGAffineTransform.init(scaleX: 1.3, y: 1.3)
        popViewOrderCategories.alpha = 0
        UIView.animate(withDuration: 0.4) {
            self.popViewOrderCategories.alpha = 1
            self.popViewOrderCategories.transform = CGAffineTransform.identity
        }
    }
    
    public func animateOut () {
        UIView.animate(withDuration: 0.3, animations: {
            self.popViewOrderCategories.transform = CGAffineTransform.init(scaleX: 2.0, y: 2.0)
            self.popViewOrderCategories.alpha = 0
        }) { (success:Bool) in
            self.popViewOrderCategories.transform = CGAffineTransform.init(scaleX: 1.0, y: 1.0)
            self.popViewOrderCategories.removeFromSuperview()
        }
    }
}
