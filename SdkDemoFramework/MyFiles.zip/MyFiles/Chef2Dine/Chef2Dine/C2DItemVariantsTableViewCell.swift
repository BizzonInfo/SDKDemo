//
//  C2DItemVariantsTableViewCell.swift
//  Chef2Dine
//
//  Created by Bon User on 1/21/17.
//  Copyright © 2017 Bon User. All rights reserved.
//

import UIKit

class C2DItemVariantsTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
