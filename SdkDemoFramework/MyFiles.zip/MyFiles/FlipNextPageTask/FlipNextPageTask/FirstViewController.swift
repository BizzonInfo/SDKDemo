//
//  FirstViewController.swift
//  FlipNextPageTask
//
//  Created by BonMac21 on 1/21/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
  //navigationController?.isNavigationBarHidden = true
        // Do any additional setup after loading the view.
    }

    @IBAction func btnNextPressed(_ sender: Any) {
      let secondVc = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        UIView.beginAnimations("Flip", context: nil)
        UIView.setAnimationDuration(1.0)
        UIView.setAnimationCurve(UIViewAnimationCurve.easeInOut)
        UIView.setAnimationTransition(UIViewAnimationTransition.flipFromRight, for: (self.navigationController?.view)!, cache: false)
        self.navigationController?.pushViewController(secondVc, animated: true)
        UIView.commitAnimations()
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    


}
