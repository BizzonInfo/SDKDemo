//
//  SecondViewController.swift
//  FlipNextPageTask
//
//  Created by BonMac21 on 1/21/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       // navigationController?.isNavigationBarHidden = true
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btnNextPressed(_ sender: Any) {
        UIView.beginAnimations("Flip", context: nil)
        UIView.setAnimationDuration(1.0)
        UIView.setAnimationCurve(UIViewAnimationCurve.easeInOut)
        UIView.setAnimationTransition(UIViewAnimationTransition.flipFromLeft, for: (self.navigationController?.view)!, cache: false)
     let _ = self.navigationController?.popViewController(animated: true)
        UIView.commitAnimations()
    }

}
