//
//  SecureViewController.swift
//  FireBaseStartDemo
//
//  Created by BonMac21 on 5/16/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth
import CoreTelephony

class SecureViewController: UIViewController {

    var ref: FIRDatabaseReference!
    var activity_location = "kazhakootam"
    var activity_Date = ""
    var activity_Time = ""
    var activity_Networkprovider = "Asianet"
    var current_Page = "Security"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ref = FIRDatabase.database().reference()
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy"
        let result = formatter.string(from: date)
        activity_Date = result
        let calender = NSCalendar.current
        let hour = calender.component(.hour, from: date)
        let minute = calender.component(.minute, from: date)
        activity_Time = "\(hour):\(minute)"
        getNetworkProviderName()
        updateCurrentActivityLog()
        navigationItem.title = "Security"
    }
    
    func getNetworkProviderName() {
        let networkInfo = CTTelephonyNetworkInfo()
        let carrier = networkInfo.subscriberCellularProvider
        let carrierName = carrier?.carrierName
        //activity_Networkprovider = carrierName!
        
    }
    
    func updateCurrentActivityLog() {
        let key = ref.child("activity_log").childByAutoId().key
        let post = ["current_Page": current_Page,"activity_location": activity_location,
                    "activity_Time": activity_Time,
                    "activity_Date": activity_Date,
                    "activity_Networkprovider": activity_Networkprovider]
        let childUpdates = ["/activity_log/\(key)": post]
        ref.updateChildValues(childUpdates)
    }
    
    
    @IBAction func buttonNextPressed(_ sender: Any) {
        let nextVc = self.storyboard?.instantiateViewController(withIdentifier: "SecureHomeViewController") as! SecureHomeViewController
        self.navigationController?.pushViewController(nextVc, animated: true)
        
    }


}
