//
//  HomeViewController.swift
//  FireBaseStartDemo
//
//  Created by BonMac21 on 5/16/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth
import CoreTelephony


class HomeViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet var popUpView: UIView!
    @IBOutlet var personalDetailPopUp: UIView!
    @IBOutlet weak var textFieldSecurityCode: UITextField!
    @IBOutlet weak var textFieldName: UITextField!
    @IBOutlet weak var textFieldEmail: UITextField!
    @IBOutlet weak var textFieldPhoneNum: UITextField!
    

     var ref: FIRDatabaseReference!
     var activity_location = "kazhakootam"
     var activity_Date = ""
     var activity_Time = ""
     var activity_Networkprovider = "Asianet"
     var current_Page = "Home"
     var buttonCount = 0
     var authenticationStatus = ""
     var dateAndTime = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textFieldSecurityCode.delegate = self
        textFieldName.delegate = self
        textFieldEmail.delegate = self
        textFieldPhoneNum.delegate = self
        ref = FIRDatabase.database().reference()
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        let result = formatter.string(from: date)
        activity_Date = result
        let calender = NSCalendar.current
        let hour = calender.component(.hour, from: date)
        let minute = calender.component(.minute, from: date)
        activity_Time = "\(hour):\(minute)"
        dateAndTime = "\(activity_Date) \(activity_Time) hh:mm"
        getNetworkProviderName()
        updateCurrentActivityLog()
        FIRAnalytics.logEvent(withName: "Home", parameters: nil)
    //    FIRAnalytics.logEvent(withName: kFIREventSelectContent, parameters: [kFIRParameterItemID: "id-\(title!)" as NSObject,
                                //                         kFIRParameterItemName: title! as NSObject,
                                //                        kFIRParameterContentType: "cont" as NSObject])
    }
    
    func getNetworkProviderName() {
        let networkInfo = CTTelephonyNetworkInfo()
        let carrier = networkInfo.subscriberCellularProvider
        let carrierName = carrier?.carrierName
       //activity_Networkprovider = carrierName!
     }
    
    func updateCurrentActivityLog() {
        let key = ref.child("activity_log").childByAutoId().key
        let post = ["current_Page": current_Page,"activity_location": activity_location,
                    "activity_Time": activity_Time,
                    "activity_Date": activity_Date,
                    "activity_Networkprovider": activity_Networkprovider]
        let childUpdates = ["/activity_log/\(key)": post]
        ref.updateChildValues(childUpdates)
    }
    

    @IBAction func buttonNextPressed(_ sender: Any) {
//        let ref = FIRDatabase.database().reference().child("activity_log")
//        ref.observe(.value) { (snap: FIRDataSnapshot) in
//            self.labelName.text = snap.value.unsafelyUnwrapped as? String
//        }
        popUpView.center = self.view.center
        self.view.addSubview(popUpView)
  
    }
    
    @IBAction func sendButtonPressed(_ sender: UIButton) {
        if CAUtils.isWhiteSpace(textFieldSecurityCode.text!) {
            CAUtils.showToastWithTitle("Please Enter the Security Code")
        } else {
            self.buttonCount += 1
            if buttonCount >= 10 {
                self.popUpView.removeFromSuperview()
                personalDetailPopUp.center = self.view.center
                self.view.addSubview(personalDetailPopUp)
            } else {
                if textFieldSecurityCode.text == "123456" {
                    let nextVc = self.storyboard?.instantiateViewController(withIdentifier: "SecureViewController") as! SecureViewController
                    popUpView.removeFromSuperview()
                    textFieldSecurityCode.text = ""
                    authenticationStatus = "SUCCESS"
                    authenticationActivityLog()
                    self.navigationController?.pushViewController(nextVc, animated: true)
                } else {
                    let alert = UIAlertController(title: "Alert", message: "Please Enter the Correct Security Code", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
                    authenticationStatus = "Failed"
                    textFieldSecurityCode.text = ""
                    authenticationActivityLog()
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    func authenticationActivityLog() {
         let device_id = UIDevice.current.identifierForVendor?.uuidString
         let key = ref.child("authentication_Status").childByAutoId().key
         let post = ["status": authenticationStatus,"Device_UDID": device_id]
         let childUpdates = ["/authentication_Status/\(key)": post]
         ref.updateChildValues(childUpdates)
    }
    
    @IBAction func personalDetailEnterPressed(_ sender: UIButton) {
        if self.isFieldsValid() {
            let nextVc = self.storyboard?.instantiateViewController(withIdentifier: "SecureViewController") as! SecureViewController
            personalDetailPopUp.removeFromSuperview()
            authenticationStatus = "SUCCESS"
            sendPersonalDetails()
            authenticationActivityLog()
            self.navigationController?.pushViewController(nextVc, animated: true)
        }
    }
    

    func sendPersonalDetails() {
        let key = ref.child("authentication_Status").childByAutoId().key
        let post = ["Name": textFieldName.text, "E-mail": textFieldEmail.text, "Phone No" : textFieldPhoneNum.text]
        let childUpdates = ["/Personal_Details/\(key)": post]
        ref.updateChildValues(childUpdates)
    }
    
    
    func isFieldsValid() -> Bool{
        if CAUtils.isWhiteSpace(self.textFieldEmail.text!){
            CAUtils.showToastWithTitle("Enter Email")
            return false
        }else if CAUtils.isWhiteSpace(self.textFieldName.text!){
            CAUtils.showToastWithTitle("Enter Name")
            return false
        }else if CAUtils.isWhiteSpace(self.textFieldPhoneNum.text!){
            CAUtils.showToastWithTitle("Enter  Phone Number")
            return false
        }
        if !CAUtils.checkEmailValidation(self.textFieldEmail.text!){
            CAUtils.showToastWithTitle("Enter a valid Email")
            return false
        }
        else {
            return true
        }
    }

    
    func popupViewCornerRadius() {
        popUpView.layer.cornerRadius = 10;
        popUpView.layer.masksToBounds = true;
        popUpView.layer.borderColor = UIColor.gray.cgColor;
        popUpView.layer.borderWidth = 0.5;
        popUpView.layer.contentsScale = UIScreen.main.scale;
        popUpView.layer.shadowColor = UIColor.black.cgColor;
        popUpView.layer.shadowOffset = CGSize.zero
        popUpView.layer.shadowRadius = 5.0;
        popUpView.layer.shadowOpacity = 0.5;
        popUpView.layer.masksToBounds = false;
        popUpView.clipsToBounds = false;
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let nextTag = textField.tag + 1
        let nextResponder = textField.superview?.superview?.superview?.viewWithTag(nextTag)
        if nextResponder != nil{
            nextResponder?.becomeFirstResponder()
        }else{
            textField.resignFirstResponder()
        }
        return true
    }

}
