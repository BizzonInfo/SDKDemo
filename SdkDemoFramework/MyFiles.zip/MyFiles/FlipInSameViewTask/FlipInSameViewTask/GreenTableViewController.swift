//
//  GreenTableViewController.swift
//  FlipInSameViewTask
//
//  Created by BonMac21 on 1/23/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class GreenTableViewController: UITableViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
          navigationController?.navigationBar.barTintColor = UIColor.green
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 15
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! TableViewCell
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let nextVc = self.storyboard?.instantiateViewController(withIdentifier: "RedTableViewController") as! RedTableViewController
        UITableView.beginAnimations("Flip", context: nil)
        UITableView.setAnimationDuration(1.0)
       // UITableView.setAnimationCurve(UIViewAnimationCurve.easeInOut)
        UITableView.setAnimationTransition(UIViewAnimationTransition.flipFromRight, for: (self.navigationController?.view)!, cache: false)
        navigationController?.pushViewController(nextVc, animated: true)
        UITableView.commitAnimations()
    }
    
    
}
