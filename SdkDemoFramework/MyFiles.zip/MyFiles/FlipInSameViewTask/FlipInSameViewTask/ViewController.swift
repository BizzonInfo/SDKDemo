//
//  ViewController.swift
//  FlipInSameViewTask
//
//  Created by BonMac21 on 1/21/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var containerView1: UIView!
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        if sender.isSelected {
            UITableView.beginAnimations("Flip", context: nil)
            UITableView.setAnimationDuration(1.0)
            UITableView.setAnimationCurve(UIViewAnimationCurve.easeInOut)
            UITableView.setAnimationTransition(UIViewAnimationTransition.flipFromRight, for: (self.navigationController?.view)!, cache: false)
            self.containerView1.isHidden = false
        }else {
            UITableView.beginAnimations("Flip", context: nil)
            UITableView.setAnimationDuration(1.0)
            UITableView.setAnimationCurve(UIViewAnimationCurve.easeInOut)
            UITableView.setAnimationTransition(UIViewAnimationTransition.flipFromRight, for: (self.navigationController?.view)!, cache: false)
            self.containerView1.isHidden = true
        }
      
    }
    
    
    
    
//    @IBAction func showComponenet(sender: UISegmentedControl) {
//        if sender.selectedSegmentIndex == 0 {
//            UIView.animateWithDuration(0.8, animations: {
//                self.containerView1.hidden = false
//                self.containerView2.hidden = true
//            })
//        } else {
//            UIView.animateWithDuration(0.8, animations: {
//                self.containerView1.hidden = true
//                self.containerView2.hidden = false
//            })
//        }
}

