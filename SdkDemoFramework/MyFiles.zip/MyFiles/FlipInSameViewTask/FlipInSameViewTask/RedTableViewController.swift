//
//  RedTableViewController.swift
//  FlipInSameViewTask
//
//  Created by BonMac21 on 1/23/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class RedTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    navigationController?.navigationBar.barTintColor = UIColor.red
     
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
    
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 15
    }

 


}
