//
//  TaskVc2.swift
//  ValuePassingTest
//
//  Created by BonMac21 on 12/12/16.
//  Copyright © 2016 BonMac21. All rights reserved.
//

import UIKit
//protocol MyProtocol {
//    func setResultOfBusinessLogic(valueSent: String)
//}

class TaskVc2: UIViewController {
    
    @IBOutlet weak var txtFieldValue: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtFieldValue.layer.backgroundColor = UIColor.white.cgColor
        txtFieldValue.layer.borderColor = UIColor.black.cgColor
        txtFieldValue.layer.borderWidth = 2.0
        self.navigationItem.setHidesBackButton(true, animated:true);
    }
    
    @IBAction func btnActionSubmit(_ sender: UIButton) {
        let myDict = ["number": txtFieldValue.text]
        NotificationCenter.default.post(name: Notification.Name("NotificationIdentifier"), object: nil, userInfo: myDict)
        let _ = self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
}
