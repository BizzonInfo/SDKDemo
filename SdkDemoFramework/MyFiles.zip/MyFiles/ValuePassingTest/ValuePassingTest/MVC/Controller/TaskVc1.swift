//
//  TaskVc1.swift
//  ValuePassingTest
//
//  Created by BonMac21 on 12/12/16.
//  Copyright © 2016 BonMac21. All rights reserved.
//
import Foundation
import UIKit


class TaskVc1: UIViewController {
    
    @IBOutlet weak var lblDisplay: UILabel!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       let notificationName = Notification.Name("NotificationIdentifier")
       NotificationCenter.default.addObserver(self, selector: #selector(TaskVc1.catchNotification), name: notificationName, object: nil)
    }
    
    func catchNotification(notification:NSNotification) {
        lblDisplay.text = notification.userInfo?["number"] as? String
        print("\(lblDisplay.text)")
    }
    
  
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
