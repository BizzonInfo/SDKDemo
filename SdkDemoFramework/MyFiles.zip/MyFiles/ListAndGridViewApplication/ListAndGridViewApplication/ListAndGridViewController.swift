//
//  ListAndGridViewController.swift
//  ListAndGridViewApplication
//
//  Created by BonMac21 on 1/7/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class ListAndGridViewController: UIViewController{

    @IBOutlet weak var containerView1: UIView!
    @IBOutlet weak var containerView2: UIView!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if segmentedControl.selectedSegmentIndex == 0 {
            UIView.animateWithDuration(0.5, animations: {
                self.containerView1.hidden = false
                self.containerView2.hidden = true
            })
        } else if segmentedControl.selectedSegmentIndex == 1 {
            UIView.animateWithDuration(0.5, animations: {
                self.containerView1.hidden = true
                self.containerView2.hidden = false
            })
        }
    }

  
    
    @IBAction func showComponenet(sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
       UIView.animateWithDuration(0.8, animations: {
                self.containerView1.hidden = false
                self.containerView2.hidden = true
            })
        } else {
            UIView.animateWithDuration(0.8, animations: {
                self.containerView1.hidden = true
                self.containerView2.hidden = false
            })
        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

  

}
