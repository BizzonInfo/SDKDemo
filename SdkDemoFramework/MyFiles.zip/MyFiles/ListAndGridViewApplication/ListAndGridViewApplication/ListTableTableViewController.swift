//
//  ListTableTableViewController.swift
//  ListAndGridViewApplication
//
//  Created by BonMac21 on 1/9/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class ListTableTableViewController: UITableViewController {
    
    @IBOutlet var tableViewList: UITableView!
    var fruitsNameArray = ["Apple","Orange","Pome","Banana","Guava","Papaya","Watermelon","Pineapple","Strawberry"]
    var imageArray = [UIImage.init(named: "Apple"),UIImage.init(named: "Orange"), UIImage.init(named: "Pome"),UIImage.init(named: "Banana"), UIImage.init(named: "Guava"), UIImage.init(named: "Papaya"), UIImage.init(named: "Watermelon"), UIImage.init(named: "Pineapple"),UIImage.init(named: "Strawberry")]

    override func viewDidLoad() {
        super.viewDidLoad()
         tableViewList.delegate = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fruitsNameArray.count
    }
  
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCellWithIdentifier("Cell") as! ListTableViewCell
      cell.imageViewdisplayImage.image = imageArray[indexPath.row]
      cell.labelName.text = fruitsNameArray[indexPath.row]
      return cell
    }
 
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print(indexPath.row)
        let cell = tableViewList.cellForRowAtIndexPath(indexPath)
        UIView.animateWithDuration(0.3, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 10, options: [], animations: {
            cell!.transform = CGAffineTransformMakeScale(0.9, 0.9)
        }) { finished in
            UIView.animateWithDuration(0.3, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 5, options: .CurveEaseInOut, animations: {
                cell?.transform = CGAffineTransformMakeScale(1, 1)
                }, completion: nil)
        }

//        let nextViewController = self.storyboard?.instantiateViewControllerWithIdentifier("SelectedImageViewController") as! SelectedImageViewController
//        let indexPaths = self.tableViewList.indexPathsForSelectedRows
//        let indexPath = indexPaths![0] as NSIndexPath
//        nextViewController.image = imageArray[indexPath.row]!
//        nextViewController.title = fruitsNameArray[indexPath.row]
//        self.navigationController?.pushViewController(nextViewController, animated: true)
        
    }
    
    
 

}
