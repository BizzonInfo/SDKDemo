//
//  GridCollectionViewController.swift
//  ListAndGridViewApplication
//
//  Created by BonMac21 on 1/9/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"

class GridCollectionViewController: UICollectionViewController {
    
    @IBOutlet var collectionViewGrid: UICollectionView!
    var fruitsNameArray = ["Apple","Orange","Pome","Banana","Guava","Papaya","Watermelon","Pineapple","Strawberry","Orange","Pome","Banana","Guava","Papaya","Watermelon"]
    var imageFruitsArray = [UIImage.init(named: "Apple"),UIImage.init(named: "Orange"), UIImage.init(named: "Pome"),UIImage.init(named: "Banana"), UIImage.init(named: "Guava"), UIImage.init(named: "Papaya"), UIImage.init(named: "Watermelon"),UIImage.init(named: "Pineapple"),UIImage.init(named: "Strawberry"),UIImage.init(named: "Orange"), UIImage.init(named: "Pome"),UIImage.init(named: "Banana"), UIImage.init(named: "Guava"), UIImage.init(named: "Papaya"), UIImage.init(named: "Watermelon")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fruitsNameArray.count
    }

 
    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("Cell", forIndexPath: indexPath) as! GridCollectionViewCell
        cell.imageViewGrid.image = imageFruitsArray[indexPath.row]
        cell.labelName.text = fruitsNameArray[indexPath.row]
        return cell
    }
    
  
   
    override func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        let cell = collectionView.cellForItemAtIndexPath(indexPath)
        UIView.animateWithDuration(0.3, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 5, options: [], animations: {
            cell!.transform = CGAffineTransformMakeScale(0.9, 0.9)
            }) { finished in
                UIView.animateWithDuration(0.3, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 5, options: .CurveEaseInOut, animations: {
                    cell?.transform = CGAffineTransformMakeScale(1, 1)
                    }, completion: nil)
        }
        let nextViewController = self.storyboard?.instantiateViewControllerWithIdentifier("SelectedImageViewController") as! SelectedImageViewController
        let indexPaths = self.collectionView?.indexPathsForSelectedItems()
        let indexPath = indexPaths![0] as NSIndexPath
        nextViewController.image = self.imageFruitsArray[indexPath.row]!
        nextViewController.title = self.fruitsNameArray[indexPath.row]
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
   
}
