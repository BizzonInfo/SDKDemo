//
//  GridCollectionViewCell.swift
//  ListAndGridViewApplication
//
//  Created by BonMac21 on 1/9/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class GridCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewGrid: UIImageView!
    @IBOutlet weak var labelName: UILabel!
    
    
    
}
