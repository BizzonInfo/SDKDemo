//
//  File.swift
//  LeftMenuTask
//
//  Created by BonMac21 on 1/20/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit
extension UIViewController {
    
    func setNavigationBarItem() {
        
        self.navigationController?.navigationBar.tintColor = UIColor.white//.withAlphaComponent(0.5)
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]//.withAlphaComponent(0.5)]
        self.navigationController?.navigationBar.barTintColor = UIColor.red
        self.addLeftBarButtonWithImage(UIImage(named: "ic_menu_black_24dp")!)
        self.slideMenuController()?.removeLeftGestures()
        self.slideMenuController()?.removeRightGestures()
        self.slideMenuController()?.addLeftGestures()
        self.slideMenuController()?.addRightGestures()
    }}
