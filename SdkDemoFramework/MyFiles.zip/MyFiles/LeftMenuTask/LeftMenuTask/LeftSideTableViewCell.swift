//
//  LeftSideTableViewCell.swift
//  LeftMenuTask
//
//  Created by BonMac21 on 1/20/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class LeftSideTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var labelTitle: UILabel!
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func customizeCellWithDetails(title:String,imageName:String) {
        self.labelTitle.adjustsFontSizeToFitWidth=true
        //self.labelTitle.textColor=CAUtils.getColorFromHexString(materialRedColor)
        self.labelTitle.text=title
        self.imageview.image=UIImage(named: imageName)
        self.imageview.image = self.imageview.image?.withRenderingMode(.alwaysTemplate)
        self.imageview.tintColor = .black
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
