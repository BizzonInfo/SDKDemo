//
//  HomeViewController.swift
//  LeftMenuTask
//
//  Created by BonMac21 on 1/20/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit
enum LeftMenu: Int {
    case first = 0
    case second
    case third
    case fourth
    case fifth
   // case settings
    //    case logout
}

//protocol LeftMenuProtocol : class {
//    func changeViewController(_ menu: LeftMenu)
//}


class HomeViewController: UITableViewController {
    
    
    @IBOutlet var headerView: UIView!
    
    var arrayValues = ["First", "Second", "Third", "Fourth", "Fifth"]
    var mainViewController = UIViewController()
    var firstViewController: UIViewController!
    var secondViewController: UIViewController!
    var thirdViewController: UIViewController!
    var fourthViewController: UIViewController!
    var fifthViewController: UIViewController!
    var currentRow = 0
    var lastSelectedRow = 0
    var sideMenuIndex:Int? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        self.headerView.layoutIfNeeded()
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let firstVc = storyboard.instantiateViewController(withIdentifier: "FirstViewController") as! FirstViewController
        self.firstViewController = UINavigationController(rootViewController: firstVc)
        
        let secondVc = storyboard.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        self.secondViewController = UINavigationController(rootViewController: secondVc)
        
        let thirdVc = storyboard.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        self.thirdViewController = UINavigationController(rootViewController: thirdVc)
        
        let fourthVc = storyboard.instantiateViewController(withIdentifier: "FourthViewController") as! FourthViewController
        self.fourthViewController = UINavigationController(rootViewController: fourthVc)
        
        let fifthVc = storyboard.instantiateViewController(withIdentifier: "FifthViewController") as! FifthViewController
        self.fifthViewController = UINavigationController(rootViewController: fifthVc)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let image = UIImage(named: "Profilepic")
        UIGraphicsBeginImageContext(headerView.frame.size)
        image?.draw(in: CGRect(x: 0, y: 0, width: (self.slideMenuController()?.leftViewController?.view.bounds.width)!, height: 200), blendMode: .colorBurn, alpha: 1.0)
        let patternImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        headerView.contentMode = .scaleAspectFill
        headerView.backgroundColor=UIColor(patternImage: patternImage!)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayValues.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! LeftSideTableViewCell
        cell.customizeCellWithDetails(title: self.arrayValues[indexPath.row], imageName: self.arrayValues[indexPath.row])
        cell.backgroundColor=currentRow == (indexPath as NSIndexPath).row ? UIColor.lightGray: UIColor.clear
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        lastSelectedRow=currentRow;
        currentRow=(indexPath as NSIndexPath).row
       // sideMenuIndex = indexPath.row
        if let menu = LeftMenu(rawValue: indexPath.row) {
            self.changeViewController(menu)
        }
        tableView .reloadRows(at: [IndexPath(row: lastSelectedRow, section: 0),IndexPath(row: currentRow, section: 0)], with:UITableViewRowAnimation.automatic )
    }
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return headerView
    }
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 200
    }
    
    func changeViewController(_ menu: LeftMenu) {
        switch menu {
        case .first:
            self.slideMenuController()?.changeMainViewController(self.firstViewController, close: true)
        case .second:
            self.slideMenuController()?.changeMainViewController(self.secondViewController, close: true)
        case .third:
            self.slideMenuController()?.changeMainViewController(self.thirdViewController, close: true)
        case .fourth:
            self.slideMenuController()?.changeMainViewController(self.fourthViewController, close: true)
        case .fifth:
            self.slideMenuController()?.changeMainViewController(self.fifthViewController, close: true)
        }
    }

}
