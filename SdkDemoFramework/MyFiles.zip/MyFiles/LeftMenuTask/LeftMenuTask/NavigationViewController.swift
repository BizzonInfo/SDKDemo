//
//  NavigationViewController.swift
//  LeftMenuTask
//
//  Created by BonMac21 on 1/20/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class NavigationViewController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    



}
