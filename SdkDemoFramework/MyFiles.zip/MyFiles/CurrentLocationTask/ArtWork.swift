//
//  ArtWork.swift
//  CurrentLocationTask
//
//  Created by BonMac21 on 1/23/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import Foundation
import MapKit
import AddressBook

class ArtWork: NSObject,MKAnnotation {
    
    let titleName: String!
    let locationName: String!
    let discipline: String!
    let coordinate: CLLocationCoordinate2D
    
    init(title: String, locationName: String!, discipline: String!, coordinate: CLLocationCoordinate2D) {
        self.titleName = title
        self.locationName = locationName
        self.discipline = discipline
        self.coordinate = coordinate
        super.init()
        
    }
    
    fileprivate var subTitle: String {
        return locationName
    }
    
    func mapItem() -> MKMapItem {
        let addressDictionary = [String(kABPersonAddressStreetKey): subTitle]
        let placemark = MKPlacemark(coordinate: coordinate, addressDictionary: addressDictionary)
        
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = titleName
        return mapItem
    }
}
    
    
