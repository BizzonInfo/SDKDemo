//
//  ViewController.swift
//  CurrentLocationTask
//
//  Created by BonMac21 on 1/23/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    @IBOutlet weak var theMap: MKMapView!
    
    @IBOutlet weak var labelLatitude: UILabel!
    @IBOutlet weak var labelLongitude: UILabel!
    @IBOutlet weak var labelAddress1: UILabel!
    @IBOutlet weak var labelAddress2: UILabel!
    @IBOutlet weak var labelAddress3: UILabel!
   
    
    let locationManager =  CLLocationManager()
    let newPin = MKPointAnnotation()
    var latitude = Float()
    var longitude = Float()
    
    override func viewDidLoad() {
        super.viewDidLoad()
   
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        if #available(iOS 8.0, *) {
            locationManager.requestAlwaysAuthorization()
        } else {
            // Fallback on earlier versions
        }
        locationManager.startUpdatingLocation()
        
        // add gesture recognizer
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(ViewController.mapLongPress(_:))) // colon needs to pass through info
        longPress.minimumPressDuration = 1.5 // in seconds
        //add gesture recognition
        theMap.addGestureRecognizer(longPress)
    }
    
    // func called when gesture recognizer detects a long press
    
    func mapLongPress(_ recognizer: UIGestureRecognizer) {
        
        print("A long press has been detected.")
        
        let touchedAt = recognizer.location(in: self.theMap) // adds the location on the view it was pressed
        let touchedAtCoordinate : CLLocationCoordinate2D = theMap.convert(touchedAt, toCoordinateFrom: self.theMap) // will get coordinates
        
        let newPin = MKPointAnnotation()
        newPin.coordinate = touchedAtCoordinate
        theMap.addAnnotation(newPin)
        
        
    }
    

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        CLGeocoder().reverseGeocodeLocation(manager.location!, completionHandler: {(placemarks, error)-> Void in
            if (error != nil) {
                print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                return
            }
            
            if (placemarks?.count) != 0 {
                let pm = placemarks?[0]
                self.displayLocationInfo(placemark: pm!)
            } else {
                print("Problem with the data received from geocoder")
            }
        })
       
        theMap.removeAnnotation(newPin)
        let location = locations.last! as CLLocation
        latitude = Float(location.coordinate.latitude)
        longitude = Float(location.coordinate.longitude)
        labelLatitude.text = "\(latitude)"
        labelLongitude.text = "\(longitude)"
        
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        //set region on the map
        theMap.setRegion(region, animated: true)
        
//        newPin.coordinate = location.coordinate
//        theMap.addAnnotation(newPin)
        
    }
    
    func displayLocationInfo(placemark: CLPlacemark) {
            print(placemark.subLocality ?? "")
            print(placemark.locality ?? "")
            print(placemark.postalCode ?? "" )
            print(placemark.administrativeArea ?? "" )
            print(placemark.country ?? "" )
            labelAddress1.text = placemark.subLocality ?? ""
            labelAddress2.text = placemark.locality ?? ""
            labelAddress3.text = "\(placemark.postalCode ?? "") \(placemark.administrativeArea ?? "" )"
   
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        let initialLocation = CLLocation(latitude: 8.567951, longitude: 76.87417)
//        centerMapOnLocation(initialLocation)
//        let artwork = ArtWork(title: "ghfgh", locationName: "hghfg", discipline: "hfghfg", coordinate: CLLocationCoordinate2D(latitude: 21.283921, longitude: -157.831661))
//        theMap.addAnnotation(artwork)
//        theMap.delegate = self
//    }
//    
//    
//    func centerMapOnLocation(_ location: CLLocation) {
//        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
//                                                                  regionRadius * 2.0, regionRadius * 2.0)
//        theMap.setRegion(coordinateRegion, animated: true)
//    }
//
//    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
//        if let annotation = annotation as? ArtWork {
//            let identifier = "pin"
//            var view : MKPinAnnotationView
//            if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier){
//                dequeuedView.annotation = annotation
//                view = dequeuedView as! MKPinAnnotationView
//            } else {
//                view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
//                view.canShowCallout = true
//                view.calloutOffset = CGPoint(x: -5, y: 5)
//                view .rightCalloutAccessoryView = UIButton.init(type: .detailDisclosure)
//            }
//            view.pinColor = MKPinAnnotationColor.green
//            return view
//        }
//        return nil
//        
//    }
//    
//    
//    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
//        let location = view.annotation as! ArtWork
//        let launchOptions = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
//        location.mapItem().openInMaps(launchOptions: launchOptions)
//    }
//    
//    
//}



