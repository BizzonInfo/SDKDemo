//
//  ListTableTableViewController.swift
//  ListAndGridViewApplication
//
//  Created by BonMac21 on 1/9/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class ListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet var tableViewList: UITableView!
    var fruitsNameArray = ["Apple","Orange","Pome","Banana","Guava","Papaya","Watermelon","Pineapple","Strawberry"]
    var imageArray = [UIImage.init(named: "Apple"),UIImage.init(named: "Orange"), UIImage.init(named: "Pome"),UIImage.init(named: "Banana"), UIImage.init(named: "Guava"), UIImage.init(named: "Papaya"), UIImage.init(named: "Watermelon"), UIImage.init(named: "Pineapple"),UIImage.init(named: "Strawberry")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fruitsNameArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! ListTableViewCell
        cell.imageViewdisplayImage.image = imageArray[indexPath.row]
        cell.labelName.text = fruitsNameArray[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
        let cell = tableViewList.cellForRow(at: indexPath as IndexPath)
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 10, options: [], animations: {
            cell!.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
        }) { finished in
            UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 5, options: .curveEaseInOut, animations: {
                cell?.transform = CGAffineTransform(scaleX: 1, y: 1)
            }, completion: nil)
        }
    }
    
    
    
}


