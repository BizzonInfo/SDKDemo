//
//  PageVc.swift
//  PageViewNewController
//
//  Created by BonMac21 on 1/11/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class PageVc: UIPageViewController, UIPageViewControllerDataSource {

    lazy var vcArray: [UIViewController] = {
        return [self.VCInstance(name: "FirstVc"),
                self.VCInstance(name: "GridViewController"),
                self.VCInstance(name: "ListViewController")]
    }()
    
    
    private func VCInstance(name: String) -> UIViewController {
        return UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: name)
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.dataSource = self
        if let firstVc = vcArray.first {
            setViewControllers([firstVc], direction: .forward, animated: true, completion: nil)
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
//        for view in self.view.subviews{
//            if view is UIScrollView{
//                view.frame = UIScreen.main.bounds
//            } else if view is UIPageControl {
//                view.backgroundColor = UIColor.clear
//            }
//        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = vcArray.index(of: viewController) else {
            return nil
        }
        let nextIndex = viewControllerIndex + 1
        guard nextIndex < vcArray.count else {
            return nil
        }
        guard vcArray.count > nextIndex else {
            return nil
        }
        
        return vcArray[nextIndex]
    }
    

   
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = vcArray.index(of: viewController) else {
            return nil
        }
        let previuosIndex = viewControllerIndex - 1
        guard previuosIndex >= 0 else {
            return nil
        }
        guard vcArray.count > previuosIndex else {
            return nil
        }
        return vcArray[previuosIndex]
        
    }

    
    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return vcArray.count
    }
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        guard let firstViewController = viewControllers?.first,
            let firstViewControllerIndex = vcArray.index(of: firstViewController)else {
        return 0
        }
        return firstViewControllerIndex
    }
 
}
