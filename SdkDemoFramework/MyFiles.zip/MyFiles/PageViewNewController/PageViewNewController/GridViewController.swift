//
//  GridCollectionViewController.swift
//  ListAndGridViewApplication
//
//  Created by BonMac21 on 1/9/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"

class GridViewController: UIViewController, UICollectionViewDataSource , UICollectionViewDelegate{
    
    @IBOutlet var collectionViewGrid: UICollectionView!
    var fruitsNameArray = ["Apple","Orange","Pome","Banana","Guava","Papaya","Watermelon","Pineapple","Strawberry","Orange","Pome","Banana","Guava","Papaya","Watermelon"]
    var imageFruitsArray = [UIImage.init(named: "Apple"),UIImage.init(named: "Orange"), UIImage.init(named: "Pome"),UIImage.init(named: "Banana"), UIImage.init(named: "Guava"), UIImage.init(named: "Papaya"), UIImage.init(named: "Watermelon"),UIImage.init(named: "Pineapple"),UIImage.init(named: "Strawberry"),UIImage.init(named: "Orange"), UIImage.init(named: "Pome"),UIImage.init(named: "Banana"), UIImage.init(named: "Guava"), UIImage.init(named: "Papaya"), UIImage.init(named: "Watermelon")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fruitsNameArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath as IndexPath) as! GridCollectionViewCell
        cell.imageViewGrid.image = imageFruitsArray[indexPath.row]
        cell.labelName.text = fruitsNameArray[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
     //   let cell = collectionView.cellForItem(at: indexPath)
//        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 5, options: [], animations: {
//            cell!.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
//        }) { finished in
//            UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 5, options: .curveEaseInOut, animations: {
//                cell?.transform = CGAffineTransform(scaleX: 1, y: 1)
//            }, completion: nil)
//        }
        let nextViewController = self.storyboard?.instantiateViewController(withIdentifier: "SelectedImageViewController") as! SelectedImageViewController
        let indexPaths = collectionView.indexPathsForSelectedItems
        let indexPath = indexPaths![0] as NSIndexPath
        nextViewController.image = self.imageFruitsArray[indexPath.row]!
        nextViewController.title = self.fruitsNameArray[indexPath.row]
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
  
}
