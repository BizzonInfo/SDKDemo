//
//  ViewController.swift
//  ActionSheetTask
//
//  Created by BonMac21 on 4/26/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet var headerView: UIView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func PlayNextPressed(_ sender: Any) {
         print("PlayNext")
        
        
    }
    
    @IBAction func AddToNextPressed(_ sender: Any) {
         print("AddToNext")
        
    }

    
//    @IBAction func AddMusic(_ sender: UIButton) {
//        let alertActionSheet = UIAlertController(title: "\n\n\n\n\n\n\n\n\n\n", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
//        let margin:CGFloat = 10.0
//    //    let rect = CGRect(x: margin, y: margin, width: alertActionSheet.view.bounds.size.width - margin * 4.0, height: 120)
//      //  let customView = UIImageView(frame: rect)
//      //  customView.image = UIImage(named: "nature")
//        headerView.frame = CGRect(x: margin, y: margin, width: alertActionSheet.view.bounds.size.width - margin * 4.0, height: 200)
//        alertActionSheet.view.addSubview(headerView)
////        let addmusicAction = UIAlertAction(title: "Add Music", style: UIAlertActionStyle.default) { (alert) in
////            print("Add Music")
////        }
////        let deletemusicAction = UIAlertAction(title: "Delete Music", style: UIAlertActionStyle.default) { (alert) in
////            print("Delete Music")
////        }
//        
//        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel) { (alert) in
//            print("Delete Music")
//        }
//      //  alertActionSheet.addAction(addmusicAction)
//       // alertActionSheet.addAction(deletemusicAction)
//        alertActionSheet.addAction(cancelAction)
//        self.present(alertActionSheet, animated: true, completion: nil)
//        
//    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

