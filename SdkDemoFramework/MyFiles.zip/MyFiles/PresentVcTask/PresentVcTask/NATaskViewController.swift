//
//  NATaskViewController.swift
//  NET_App
//
//  Created by BonMac21 on 12/17/16.
//  Copyright © 2016 Bon User. All rights reserved.
//

import UIKit

class NATaskViewController: UITableViewController {
    
    @IBOutlet var labelTextArray: [UILabel]!
    
    var dataSelected: String!
    let interactor = Interactor()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let nextViewController = self.storyboard?.instantiateViewController(withIdentifier: "NATaskViewController2") as! NATaskViewController2
        nextViewController.transitioningDelegate = self
        nextViewController.valueLabel = labelTextArray[indexPath.row].text
        nextViewController.interactor = interactor
     // nextViewController.textValue = dataSelected
        self.present(nextViewController, animated: true, completion: nil)
    }
    
}

extension NATaskViewController: UIViewControllerTransitioningDelegate {
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return DismissAnimator()
    }
    
    func interactionControllerForDismissal(using animator: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
        return interactor.hasStarted ? interactor : nil
    }
}

