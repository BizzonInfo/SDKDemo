//
//  ViewController.swift
//  customNavigationBarTask
//
//  Created by BonMac21 on 5/11/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var subTitleString = "Name1, Name2, Name3"
    

    override func viewDidLoad() {
        super.viewDidLoad()
        let buttonContainer = UIView(frame: CGRect(x: 10, y: 5.5, width: 340, height: 36))
        buttonContainer.backgroundColor = UIColor.clear
        let lblTitle = UILabel(frame: CGRect(x: 50, y: 0, width: 214, height: 21))
        lblTitle.textColor = UIColor.white
        lblTitle.text = "Title To Display"
        lblTitle.font = UIFont.italicSystemFont(ofSize: 16)
        lblTitle.textAlignment = .left
        buttonContainer.addSubview(lblTitle)
        let btn = UIButton(type: .custom)
        btn.setImage(UIImage(named: "Image"), for: .normal)
        btn.frame = CGRect(x: 10, y: 0, width: 33, height: 33)
        btn.layer.cornerRadius = 15
        btn.clipsToBounds = true
        buttonContainer.addSubview(btn)
        let btn2 = UIButton(type: .custom)
        btn2.frame = CGRect(x: 50, y: 20, width: 214, height: 18)
        btn2.setTitle(subTitleString, for: .normal)
        btn2.titleLabel?.font = UIFont.italicSystemFont(ofSize: 14)
        btn2.setTitleColor(UIColor.white, for: .normal)
        btn2.addTarget(self, action: #selector(buttonTapped), for: .touchUpInside)
        btn2.contentHorizontalAlignment = .left
        btn2.backgroundColor = UIColor.clear
        buttonContainer.addSubview(btn2)
        navigationItem.titleView = buttonContainer
       //navigationController?.navigationBar.barTintColor = UIColor.green
    }

    
    func buttonTapped() {
        print(subTitleString)
    }
        
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


