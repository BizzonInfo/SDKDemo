//
//  FirstViewController.swift
//  customNavigationBarTask
//
//  Created by BonMac21 on 5/11/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.barTintColor = UIColor.green
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func buttonPressed(_ sender: Any) {
        let nextVc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.navigationItem.title = ""
        navigationController?.pushViewController(nextVc, animated: true)
        
        
    }

   

}
