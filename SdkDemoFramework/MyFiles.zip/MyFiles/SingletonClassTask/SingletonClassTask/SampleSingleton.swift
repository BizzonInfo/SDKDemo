//
//  SampleSingleton.swift
//  SingletonClassTask
//
//  Created by BonMac21 on 12/22/16.
//  Copyright © 2016 BonMac21. All rights reserved.
//

import Foundation

class MySingleton {
//    class var sharedInstance: MySingleton {
//        struct Singleton {
//            static let instance = MySingleton()
//        }
//        return Singleton.instance
//    }
    
    class var sharedInstance: MySingleton {
        struct Singleton  {
            static let instance = MySingleton()
        }
        return Singleton.instance
    }
    
    var studentName1:String?
   
    func initWithDictionary(dictData:NSDictionary){
        studentName1 = dictData["firstName"] as? String!
    }
}

