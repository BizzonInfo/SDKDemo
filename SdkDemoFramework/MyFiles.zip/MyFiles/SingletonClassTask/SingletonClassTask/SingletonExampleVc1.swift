//
//  SingletonExampleVc1.swift
//  SingletonClassTask
//
//  Created by BonMac21 on 12/22/16.
//  Copyright © 2016 BonMac21. All rights reserved.
//

import UIKit

class SingletonExampleVc1: UIViewController {
    
    @IBOutlet weak var textFieldStudentName: UITextField!
    @IBOutlet weak var textFieldClassName: UITextField!
    @IBOutlet weak var textFieldId: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        let requestURL: NSURL = NSURL(string: "http://192.168.1.218:8080/api/class/students/10136")!
//        let urlRequest: NSMutableURLRequest = NSMutableURLRequest(url: requestURL as URL)
//        let session = URLSession.shared
//        let task = session.dataTask(with: urlRequest as URLRequest) { (data, response, error) -> Void in
//            let httpResponse = response as! HTTPURLResponse
//            let statuscode = httpResponse.statusCode
//            if (statuscode == 200) {
//                do {
//                    let jsonDict = try JSONSerialization.jsonObject(with: data!, options:.allowFragments) as! NSDictionary
//                    let studentListArray = jsonDict["studentsList"] as! NSArray
//                    for student in studentListArray {
//                        let dictData = student as! NSDictionary
//                        let singleTon = MySingleton.sharedInstance
//                        singleTon.initWithDictionary(dictData: dictData)
//                   }
//                } catch{
//                    print("Error with Json: \(error)")
//                }
//            }
//        }
//        task.resume()
   }
  
    
    @IBAction func nextButton(_ sender: Any) {
      let singletonExample2 = self.storyboard?.instantiateViewController(withIdentifier: "SingletonExampleVc2") as! SingletonExampleVc2
       self.navigationController?.pushViewController(singletonExample2, animated: true)
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
