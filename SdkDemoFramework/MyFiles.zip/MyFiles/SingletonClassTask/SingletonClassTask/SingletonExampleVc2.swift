//
//  SingletonExampleVc2.swift
//  SingletonClassTask
//
//  Created by BonMac21 on 12/22/16.
//  Copyright © 2016 BonMac21. All rights reserved.
//

import UIKit

class SingletonExampleVc2: UIViewController,UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    var arrayStudent = NSMutableArray()

    override func viewDidLoad() {
        super.viewDidLoad()
        let requestURL: NSURL = NSURL(string: "http://192.168.1.218:8080/api/class/students/10136")!
        let urlRequest: NSMutableURLRequest = NSMutableURLRequest(url: requestURL as URL)
        let session = URLSession.shared
        let task = session.dataTask(with: urlRequest as URLRequest) { (data, response, error) -> Void in
            let httpResponse = response as! HTTPURLResponse
            let statuscode = httpResponse.statusCode
            if (statuscode == 200) {
                do {
                    let jsonDict = try JSONSerialization.jsonObject(with: data!, options:.allowFragments) as! NSDictionary
                    let studentListArray = jsonDict["studentsList"] as! NSArray
                    for student in studentListArray {
                        let dictData = student as! NSDictionary
                        self.arrayStudent.add(dictData)
                    }
                    self.tableView.reloadData()
                } catch{
                    print("Error with Json: \(error)")
                }
            }
        }
        task.resume()
        
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrayStudent.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! TableViewCell
        let dicData = self.arrayStudent[indexPath.row] as! NSDictionary
        cell.labelText.text = "\(dicData["firstName"]!)"
        return cell
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
