//
//  MailAndMessageViewController.swift
//  MailAndMessageComposer
//
//  Created by BonMac21 on 1/16/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class MailAndMessageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func mailButtonPressed(_ sender: UIButton) {
        let mailViewControllerObj = self.storyboard?.instantiateViewController(withIdentifier: "MailComposerViewController") as! MailComposerViewController
        self.navigationController?.pushViewController(mailViewControllerObj, animated: true)
    }
    

    @IBAction func messageButtonPressed(_ sender: UIButton) {
        let messageViewControllerObj = self.storyboard?.instantiateViewController(withIdentifier: "MessageComposerViewController") as! MessageComposerViewController
        self.navigationController?.pushViewController(messageViewControllerObj, animated: true)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
