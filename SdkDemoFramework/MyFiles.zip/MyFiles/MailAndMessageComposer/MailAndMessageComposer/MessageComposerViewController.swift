//
//  MessageComposerViewController.swift
//  MailAndMessageComposer
//
//  Created by BonMac21 on 1/16/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit
import Foundation
import MessageUI

class MessageComposerViewController: UIViewController, MFMessageComposeViewControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func smsButtonPressed(_ sender: UIButton) {
            let msg:MFMessageComposeViewController = MFMessageComposeViewController()
            msg.recipients = ["7236446823423"]
            msg.body = "txt"
            msg.messageComposeDelegate = self
        if MFMessageComposeViewController.canSendText(){
            self.present(msg,animated:true,completion:nil)
        }
        else {
            NSLog("your device do not support SMS....")
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        switch result {
        case MessageComposeResult.cancelled:
            print("Message was cancelled")
            controller.dismiss(animated: true, completion: nil)
        case MessageComposeResult.failed:
            print("Message was failed")
            controller.dismiss(animated: true, completion: nil)
        case MessageComposeResult.sent:
            print("Message was sent")
            controller.dismiss(animated: true, completion: nil)
        }
    }
}
