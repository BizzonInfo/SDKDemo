//
//  MailComposerViewController.swift
//  MailAndMessageComposer
//
//  Created by BonMac21 on 1/16/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit
import Foundation
import MessageUI

class MailComposerViewController: UIViewController, MFMailComposeViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnSendEmail(_ sender: UIButton) {
        let email = MFMailComposeViewController()
        email.mailComposeDelegate = self
        email.setSubject("Subject goes here")
        email.setMessageBody("Some example text", isHTML: false)
        email.setToRecipients(["jvabiram@gmail.com"]) // the recipient email address
        if MFMailComposeViewController.canSendMail() {
            present(email, animated: true, completion: nil)
        }
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        dismiss(animated: true, completion: nil)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
