//
//  BannerTableViewController.swift
//  googleIntegrationTaskDemo
//
//  Created by BonMac21 on 3/18/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit
import GoogleMobileAds

class BannerTableViewController: UITableViewController, GADBannerViewDelegate {
    
//This is the variable for holding the banner view:
    
//    lazy var adBannerView: GADBannerView = {
//        let adBannerView = GADBannerView(adSize: kGADAdSizeSmartBannerPortrait)
//        adBannerView.adUnitID = "ca-app-pub-5323290748118683/1206818851"
//        adBannerView.delegate = self
//        adBannerView.rootViewController = self
//        
//        return adBannerView
//    }()
    
    var adBannerView: GADBannerView?

    override func viewDidLoad() {
        super.viewDidLoad()
        adBannerView = GADBannerView(adSize: kGADAdSizeSmartBannerPortrait)
        adBannerView?.adUnitID = "ca-app-pub-8501671653071605/1974659335"
        adBannerView?.delegate = self
        adBannerView?.rootViewController = self

        adBannerView?.load(GADRequest())
        // Do any additional setup after loading the view.
    }

    
    
    
    func adViewDidReceiveAd(_ bannerView: GADBannerView) {
        print("Banner loaded successfully")
        //tableView.tableHeaderView?.frame = bannerView.frame
        //tableView.tableHeaderView = bannerView
        
        // Reposition the banner ad to create a slide down effect
//                let translateTransform = CGAffineTransform(translationX: 0, y: -bannerView.bounds.size.height)
//                bannerView.transform = translateTransform
//        
//                UIView.animate(withDuration: 0.5) {
//                    self.tableView.tableHeaderView?.frame = bannerView.frame
//                    bannerView.transform = CGAffineTransform.identity
//                    self.tableView.tableHeaderView = bannerView
//                }
        
        // Reposition the banner ad to create a slide down effect
        let translateTransform = CGAffineTransform(translationX: 0, y: -bannerView.bounds.size.height)
        bannerView.transform = translateTransform
        
        UIView.animate(withDuration: 0.5) {
            bannerView.transform = CGAffineTransform.identity
        }
        

    }
    
    func adView(_ bannerView: GADBannerView, didFailToReceiveAdWithError error: GADRequestError) {
        print("Fail to receive ads")
        print(error)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 40
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "BannerCell", for: indexPath)
        cell.textLabel?.text = "Cell \(indexPath.row+1)"
        return cell
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        let view = UIView()
//        view.backgroundColor = UIColor.red
        return adBannerView
    }
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
         return adBannerView!.frame.height
    }

   

}
