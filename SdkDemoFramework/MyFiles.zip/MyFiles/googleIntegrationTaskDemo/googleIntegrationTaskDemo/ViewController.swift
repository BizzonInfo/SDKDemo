//
//  ViewController.swift
//  googleIntegrationTaskDemo
//
//  Created by BonMac21 on 3/18/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit


class ViewController: UIViewController, GIDSignInUIDelegate, GIDSignInDelegate  {

    @IBOutlet weak var signInButton: GIDSignInButton!
    @IBOutlet weak var signInButtonSecond: GIDSignInButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance().delegate = self
        // Do any additional setup after loading the view, typically from a nib.
        signInButton.style = .iconOnly
        signInButton.colorScheme = .light
       // signInButton.style = .standard
        //signInButton.style = .wide
    }
    
    @IBAction func signInPressed(_ sender: UIButton) {
        GIDSignIn.sharedInstance().signIn()
        
    }

    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if (error == nil) {
            var firstName = ""
            var lastName = ""
            
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
            let url = NSURL(string:  "https://www.googleapis.com/oauth2/v3/userinfo?access_token=\(user.authentication.accessToken!)")
            let session = URLSession.shared
            session.dataTask(with: url! as URL) {(data, response, error) -> Void in
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
                do {
                    let userData = try JSONSerialization.jsonObject(with: data!, options:[]) as? [String:AnyObject]
                    /*
                     Get the account information you want here from the dictionary
                     Possible values are
                     "id": "...",
                     "email": "...",
                     "verified_email": ...,
                     "name": "...",
                     "given_name": "...",
                     "family_name": "...",
                     "link": "https://plus.google.com/...",
                     "picture": "https://lh5.googleuserco...",
                     "gender": "...",
                     "locale": "..."
                     
                     so in my case:
                     */
                    firstName = userData!["given_name"] as! String
                    lastName = userData!["family_name"] as! String
                    print(firstName)
                    print(lastName)
                } catch {
                    NSLog("Account Information could not be loaded")
                }
                }.resume()
        }
        else {
            //Login Failed
        }

    }
    
    
   
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

