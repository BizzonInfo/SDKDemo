//
//  PasswordViewController.swift
//  PasswordFeatureApplication
//
//  Created by BonMac21 on 1/16/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class PasswordViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var textFieldUserName: UITextField!
    @IBOutlet weak var textFieldPassword: UITextField!
    @IBOutlet weak var hideButton: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.textFieldUserName.delegate = self
        self.textFieldPassword.delegate = self
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func buttonPasswordPressed(_ sender: UIButton) {
        textFieldPassword.isSecureTextEntry = !textFieldPassword.isSecureTextEntry
        if textFieldPassword.isSecureTextEntry {
            hideButton.setImage(UIImage(named: "EyeClosed"), for: .normal)
        } else {
            hideButton.setImage(UIImage(named: "EyeOpened"), for: .normal)
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    
}
