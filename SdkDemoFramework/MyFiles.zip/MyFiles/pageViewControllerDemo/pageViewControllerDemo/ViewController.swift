//
//  ViewController.swift
//  pageViewControllerDemo
//
//  Created by BonMac21 on 3/29/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class Vehicle {
    var currentSpeed = 0.0
    var description: String {
        return "traveling at \(currentSpeed) miles per hour"
    }
    
    func makeNoise() {
        // do nothing - an arbitrary vehicle doesn't necessarily make a noise
    }
    
}
let someVehicle = Vehicle()

func viewDidLoad() {
   print("Vehicle: \(someVehicle.description)")
    
}

class Bicycle: Vehicle {
    var hasBasket = false
}
let bicycle = Bicycle()
