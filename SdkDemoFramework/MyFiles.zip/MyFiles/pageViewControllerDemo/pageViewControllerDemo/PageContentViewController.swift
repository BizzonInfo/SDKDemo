//
//  ViewController.swift
//  pageViewControllerDemo
//
//  Created by BonMac21 on 3/23/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class PageContentViewController: UIViewController {
    
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    var pageIndex: Int = 0
    var strTitle: String!
    var strPhotoName: String = "" {
        didSet{
            if let imageView = self.imageView{
                imageView.image = UIImage(named: strPhotoName)
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = UIImage(named: strPhotoName)
        labelTitle.text = strTitle
        
    }
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

