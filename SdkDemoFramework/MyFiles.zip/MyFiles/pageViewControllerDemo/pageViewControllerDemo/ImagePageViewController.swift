//
//  ImagePageViewController.swift
//  pageViewControllerDemo
//
//  Created by BonMac21 on 3/23/17.
//  Copyright © 2017 BonMac21. All rights reserved.
//

import UIKit

class ImagePageViewController: UIPageViewController, UIPageViewControllerDataSource {
    
    var arrayImageTitle: NSMutableArray! = NSMutableArray()
    var arrayImageDisplay: NSMutableArray! = NSMutableArray()
    var currentIndex =  1
    var timer = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.dataSource = self
        arrayImageTitle = ["Flower", "Banana", "FruitAndVeg", "MixedFruit", "Orange", "Pome", "Vegetables"]
        arrayImageDisplay = ["Flowers", "Banana", "FruitAndVeg", "MixedFruit", "Orange", "Pome", "Veg"]
        self.setViewControllers([getViewControllerAtIndex(index: 0)!] as [UIViewController], direction: UIPageViewControllerNavigationDirection.forward, animated: false, completion: nil)

    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timer.invalidate()
    }
   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
  
    func changeController(_ timer: Timer)  {
        if (currentIndex == NSNotFound)
        {
            
        }
         currentIndex += 1
        if (currentIndex == arrayImageTitle.count)
        {
            currentIndex = 0
        }
       
        let viewController = getViewControllerAtIndex(index: currentIndex)
        self.setViewControllers([viewController!], direction: .forward, animated: true, completion: nil)
    }
  

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {

        let pageContent = viewController as! PageContentViewController
        var index = pageContent.pageIndex
        if ((index == 0) || (index == NSNotFound))
        {
            index = self.arrayImageTitle.count

        }
         index -= 1
        return getViewControllerAtIndex(index: index)
    }
    
   
    
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        let pageContent = viewController as! PageContentViewController
        var index = pageContent.pageIndex
        if (index == NSNotFound)
        {
            return nil
        }
        index += 1
        if (index == arrayImageTitle.count)
        {
            index = 0
        }
        return getViewControllerAtIndex(index: index)
        
    }

    
    
    func getViewControllerAtIndex(index: NSInteger) -> PageContentViewController?
    {
        // Create a new view controller and pass suitable data.
        let pageContentViewController = self.storyboard?.instantiateViewController(withIdentifier: "PageContentViewController") as! PageContentViewController
        pageContentViewController.strTitle = "\(arrayImageTitle[index])"
        pageContentViewController.strPhotoName = "\(arrayImageDisplay[index])"
        pageContentViewController.pageIndex = index
        return pageContentViewController
    }
    

    
}
